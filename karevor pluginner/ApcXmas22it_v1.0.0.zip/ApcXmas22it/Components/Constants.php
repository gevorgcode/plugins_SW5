<?php

namespace ApcXmas22it\Components;

class Constants
{
    const XMAS22_PRODUCTS = [
        
        '01' => [
            'day' => '1',  
            'code' => '01122022', 
            'articleName' => 'Office 2010 Professional Plus', 
            'sArticle' => '210',   
            'img' => '1.png', 
            'percentValue' => '30',             
        ], //SW10212
        
        '02' => [
            'day' => '2',  
            'code' => '02122022', 
            'articleName' => 'Office 2013 Professional Plus', 
            'sArticle' => '209',   
            'img' => '2.png', 
            'percentValue' => '30',             
        ], //SW10211

        '03' => [
            'day' => '3',  
            'code' => '03122022', 
            'articleName' => 'Office 2016 Home and Student', 
            'sArticle' => '63',   
            'img' => '3.png', 
            'percentValue' => '40',             
        ], //SW10063
        
        '04' => [
            'day' => '4',  
            'code' => '04122022', 
            'articleName' => 'Office 2019 Home and Student', 
            'sArticle' => '237',   
            'img' => '4.png', 
            'percentValue' => '30',             
        ], //SW10239

        '05' => [
            'day' => '5',  
            'code' => '05122022', 
            'articleName' => 'Office 2021 Home and Business', 
            'sArticle' => '485',   
            'img' => '5.png', 
            'percentValue' => '40',             
        ], //SW10482
        
        '06' => [
            'day' => '6',  
            'code' => '06122022', 
            'articleName' => 'Office 2010 Home and Business', 
            'sArticle' => '58',   
            'img' => '6.png', 
            'percentValue' => '25',             
        ], //SW10058
        

        /////////////////////////////////////
        '07' => [
            'day' => '7',  
            'code' => '07122022', 
            'articleName' => 'Norton 360 Standard', 
            'sArticle' => '520',   
            'img' => '7.png', 
            'percentValue' => '1',  
            'special_product' => true,           
        ], //SW10517
        
        '08' => [
            'day' => '8',  
            'code' => '08122022', 
            'articleName' => 'Windows 7 Professional', 
            'sArticle' => '5',   
            'img' => '8.png', 
            'percentValue' => '15',             
        ], //SW10005

        '09' => [
            'day' => '9',  
            'code' => '09122022', 
            'articleName' => 'Windows 8.1 Professional', 
            'sArticle' => '3',   
            'img' => '9.png', 
            'percentValue' => '25',             
        ], //SW10003

        '10' => [
            'day' => '10',  
            'code' => '10122022', 
            'articleName' => 'Windows Server 2019 Standard', 
            'sArticle' => '212',   
            'img' => '10.png', 
            'percentValue' => '35',             
        ], //SW10214

        '11' => [
            'day' => '11',  
            'code' => '11122022', 
            'articleName' => 'Windows Server 2016 Standard', 
            'sArticle' => '54',   
            'img' => '11.png', 
            'percentValue' => '40',             
        ], //SW10054

        '12' => [
            'day' => '12',  
            'code' => '12122022', 
            'articleName' => 'Office 2013 Home and Business', 
            'sArticle' => '61',   
            'img' => '12.png', 
            'percentValue' => '30',             
        ], //SW10061

        '13' => [
            'day' => '13',  
            'code' => '13122022', 
            'articleName' => 'Office 2016 Home and Business', 
            'sArticle' => '64',   
            'img' => '13.png', 
            'percentValue' => '25',             
        ], //SW10064

        '14' => [
            'day' => '14',  
            'code' => '14122022', 
            'articleName' => 'Windows 10 Professional', 
            'sArticle' => '1',   
            'img' => '14.png', 
            'percentValue' => '30',             
        ], //SW10001
        
        '15' => [
            'day' => '15',  
            'code' => '15122022', 
            'articleName' => 'Office 2021 Home and Student', 
            'sArticle' => '486',   
            'img' => '15.png', 
            'percentValue' => '40',             
        ], //SW10483

        '16' => [
            'day' => '16',  
            'code' => '16122022', 
            'articleName' => 'McAfee Internet Security 2022', 
            'sArticle' => '293',   
            'img' => '16.png', 
            'percentValue' => '30',             
        ], //SW10292

        '17' => [
            'day' => '17',  
            'code' => '17122022', 
            'articleName' => 'Windows 10 Home', 
            'sArticle' => '2',   
            'img' => '17.png', 
            'percentValue' => '40',             
        ], //SW10002

        '18' => [
            'day' => '18',  
            'code' => '18122022', 
            'articleName' => 'Windows 11 Home', 
            'sArticle' => '468',   
            'img' => '18.png', 
            'percentValue' => '45',             
        ], //SW10465

        '19' => [
            'day' => '19',  
            'code' => '19122022', 
            'articleName' => 'Office 2016 Professional Plus', 
            'sArticle' => '91',   
            'img' => '19.png', 
            'percentValue' => '30',             
        ], //p66p

        '20' => [
            'day' => '20',  
            'code' => '20122022', 
            'articleName' => 'Office 2019 Professional Plus', 
            'sArticle' => '199',   
            'img' => '20.png', 
            'percentValue' => '40',             
        ], //SW10201

        '21' => [
            'day' => '21',  
            'code' => '21122022', 
            'articleName' => 'Office 2021 Professional Plus', 
            'sArticle' => '484',   
            'img' => '21.png', 
            'percentValue' => '40',             
        ], //SW10481

        '22' => [
            'day' => '22',  
            'code' => '22122022', 
            'articleName' => 'Windows Server 2022 Standard', 
            'sArticle' => '472',   
            'img' => '22.png', 
            'percentValue' => '50',             
        ], //SW10469



        /////////////////////////
        '23' => [
            'day' => '23',  
            'code' => '23122022', 
            'articleName' => 'PSN CARD 50€', 
            // 'sArticle' => '472',   
            'img' => '23.png', 
            'percentValue' => '10',             
        ], 

        '24' => [
            'day' => '24',  
            'code' => '24122022', 
            'articleName' => 'Windows 11 Professional', 
            'sArticle' => '469',   
            'img' => '24.png', 
            'percentValue' => '60',             
        ], //SW10466


    ];        
}

// TAG 1: Office 2010 Professional Plus -> 30% Rabatt 
// TAG 2: Office 2013 Professional Plus -> 30% Rabatt 
// TAG 3: Office 2016 Home and Student -> 40% Rabatt 
// TAG 4: Office 2019 Home and Student -> 30% Rabatt 
// TAG 5: Office 2021 Home and Business -> 40% Rabatt 
// Tag 6 : Office 2010 Home and Business -> 25% Rabatt 
// Tag 7: Norton 360 Standard 1€ 
// Tag 8: Windows 7 Professional -> 15 % Rabatt 
// Tag 9: Windows 8.1 Professional - 25 % Rabatt 
// Tag 10: Windows Server 2019 Standard 35% Rabatt 
// Tag 11 : Windows Server 2016 Standard -> 40 % Rabatt 
// Tag 12: Office 2013 Home and Business -> 30% Rabatt 
// Tag 13: Office 2016 Home and Business -> 25% Rabatt 
// Tag 14: Windows 10 Professional -> 30% Rabatt 
// Tag 15: Office 2021 Home and Student -> 40% Rabatt 
// Tag 16: McAfee Internet Security -> 30% Rabatt 
// Tag 17: Windows 10 Home -> 40% Rabatt 
// Tag 18: Windows 11 Home -> 45% Rabatt 
// Tag 19: Office 2016 Professional Plus -> 30% Rabatt 
// Tag 20: Office 2019 Professional Plus -> 40% Rabatt 
// Tag 21: Office 2021 Professional Plus -> 40% Rabatt 
// Tag 22: Windows Server 2022 Standard : 50% Rabatt 
// Tag 23: PSN CARD 50€ -> 45€ 
// Tag 24: Windows 11 Professional -> 60% Rabatt

?>

