<?php

namespace ApcXmas22it\Subscriber;

use Enlight\Event\SubscriberInterface;

class TemplateSubscriber implements SubscriberInterface
{
    /**
     * @var
     */
    private $pluginDirectory;  
   
    /**
     * @param $pluginDirectory
     */
    public function __construct($pluginDirectory)
    {
        $this->pluginDirectory = $pluginDirectory;
        
    }
    /**
     * @return array
     */
    public static function getSubscribedEvents()
    {
        return [
            'Theme_Inheritance_Template_Directories_Collected' => 'onCollectTemplateDirs',     
            'Enlight_Controller_Action_PostDispatchSecure_Frontend_Detail' => 'onFrontendDetail',       
        ];
    }    
     /**
     * @param Enlight_Event_EventArgs $args
     */
    public function onCollectTemplateDirs(\Enlight_Event_EventArgs $args) {
        $dirs = $args->getReturn();
        $dirs[] = $this->pluginDirectory . '/Resources/views';
        return $dirs;
    }  
    
    public function onFrontendDetail(\Enlight_Event_EventArgs $args){ 
        $controller = $args->getSubject();
        $request = $controller->Request();     
        $view = $controller->View();     

        if ($request->getActionName() != 'index'){
            return;
        }  

        $articleId = $view->getAssign('sArticle')['articleID'];        

        if ($articleId == 529){
            $controller->redirect([
                'controller' => 'error',
                'action' => 'index',
            ]);
        }        
    }
}