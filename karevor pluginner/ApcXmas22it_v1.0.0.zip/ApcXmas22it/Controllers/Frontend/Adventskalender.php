<?php

/**
 * Class Shopware_Controllers_Frontend_Adventskalender
 */
class Shopware_Controllers_Frontend_Adventskalender extends Enlight_Controller_Action{

    protected $db;

    public function init(){
        $this->db = Shopware()->DB();
    }

    public function indexAction(){
        //tpl
    } 
}
