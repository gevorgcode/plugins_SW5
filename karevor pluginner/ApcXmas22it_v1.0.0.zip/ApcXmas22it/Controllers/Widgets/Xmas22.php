<?php

use ApcXmas22it\Components\Constants;

/**
 * Shopware_Controllers_Widgets_Xmas22
 */

class Shopware_Controllers_Widgets_Xmas22 extends Enlight_Controller_Action{    

    public function indexAction(){
        $timestamp = time();
        if ($timestamp < 1669849199 || $timestamp > 1671922799){
            return;
        }
        $day = date('d', $timestamp);

        $products = Constants::XMAS22_PRODUCTS;
        $shopUrl = Shopware()->Container()->get('router')->assemble(['controller'=>'index']);
        foreach ($products as &$product){
            $product['img_url'] = $shopUrl . 'custom/plugins/ApcXmas22it/Resources/images/products/' . $product['img'];
            if ($day > $product['day']){
                $product['state'] = 'past';
            }else if ($day == $product['day']){
                $product['state'] = 'today';
            }else if ($day < $product['day']){
                $product['state'] = 'future';
            }            
        }

        if ($day == 7){
            Shopware()->Session()->offsetSet('userCanUseBoykot', true);
        }
        
        $this->View()->assign('products', $products);
    }   
    
    public function topbarAction(){
        $timestamp = time();
        $day = date('d', $timestamp);
        $this->View()->assign('xmass22day', $day);
    }
}