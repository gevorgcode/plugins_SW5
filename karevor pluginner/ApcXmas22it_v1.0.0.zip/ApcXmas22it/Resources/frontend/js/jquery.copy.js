;(function($, window, document) {   
    
    $('*[data-copy-selector="true"]').on("click", function(){
        
        var text = $(this).children('*[data-copy="true"]').text();
        $(this).addClass('is--active-copy');   
        
        var textArea = document.createElement( "textarea" );
        textArea.value = text;
        document.body.appendChild( textArea );
        textArea.select();
        try {
            var successful = document.execCommand( 'copy' );
         } catch (err) {
            successful = false;
         } 
         document.body.removeChild( textArea );
         
        if(successful){
            
            $('.is--active-copy .text--copied').removeClass('is--hidden');
            $('.is--active-copy .text--copied').animate({opacity: 1}, 500);
            $('.is--active-copy .text--copied').animate({opacity: 0}, 1000, function() {
                $('*[data-copy-selector="true"]').removeClass('is--active-copy');       
                $('.is--active-copy .text--copied').addClass('is--hidden');
            })
        }
    })        

})(jQuery, window, document);

//EXAPLE TO USE THIS CODE 

{/* <div  data-copy-selector="true">
    <span data-copy='true'>
        some text                                                   
    </span>
    <span class="text--copied is--hidden">{s name="copied" namespace="lizenz/frontend/checkout/finish"}Скопировано{/s}</span>
    <img src="{media path='media/vector/copy_blue.svg'}">
</div> */}