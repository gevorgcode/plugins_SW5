;(function($, window, document) {

    var xmas22Popup = {        

       triggerSelectorContainer: ".xmass22-container",
       triggerSelector: ".xmas22-2-day-open",
       popupSelector: ".xmas22-fixed",
       popupSelectorActive: ".xmas22-fixed.is--active",
       closeSelector: ".xmas22--close-btn",
       closeSelectorMob: ".xmas22--close-btn-mob",

        init: function(){           
            var me = this;
            me.open();            
            me.close();            
        },

        open: function(){
            var me = this;
            $(me.triggerSelector).click(function(e){
                e.stopPropagation();    
                e.stopImmediatePropagation();  
                $(this).next().addClass('is--active');          
                // $(me.triggerSelectorContainer).addClass('is--active');                          
                setTimeout(function() {
                    $(me.closeSelectorMob).addClass('is--active');      
                }, 500);      
                $(this).next().fadeIn(500);          
            });
        },

        close: function(){
            var me = this;
            $(me.closeSelector).click(function(e){
                e.stopPropagation();    
                e.stopImmediatePropagation();                       
                // $(this).parents(me.popupSelector).fadeOut(500);   
                // setTimeout(function() {
                //     $(this).parents(me.popupSelector).removeClass('is--active'); 
                // }, 500);   
                $(me.popupSelectorActive).fadeOut(500);   
                $(me.closeSelectorMob).removeClass('is--active');
                setTimeout(function() {
                    $(me.popupSelectorActive).removeClass('is--active'); 
                     
                }, 500);  
            });
            
            // $(me.triggerSelectorContainer).click(function(e){
            //     e.stopPropagation();                          
            //     // e.stopImmediatePropagation();                          
            //     $(me.popupSelectorActive).fadeOut(500);   
            //     setTimeout(function() {
            //         $(me.popupSelectorActive).removeClass('is--active'); 
            //     }, 500);                     
            // });

        },
    };

    $(document).ready(function() {
        xmas22Popup.init();
    });    

})(jQuery, window, document);
