<?php

namespace MessageBird\Exceptions;

/**
 * Class AuthenticateException
 *
 * @package MessageBird\Exceptions
 */
class AuthenticateException extends MessageBirdException
{

}
