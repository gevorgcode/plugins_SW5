;(function ($,window,document) {
    
    // $('body').on('click','.mailbody--html-td', function(e){   
    //     if($(this).hasClass('is--seen')){             
    //         $('.is--seen+.mailbody--html').hide(500);
    //         $(this).removeClass('is--seen');
    //     }else{
    //         $(this).addClass('is--seen');  
    //         $('.is--seen+.mailbody--html').show(500);
    //         $('html, body').animate({
    //             scrollTop: $('.is--seen+.mailbody--html').offset().top - 50 //#DIV_ID is an example. Use the id of your destination on the page
    //         }, 'slow');
    //     }        
    // }); 
    
})($,window,document);    
