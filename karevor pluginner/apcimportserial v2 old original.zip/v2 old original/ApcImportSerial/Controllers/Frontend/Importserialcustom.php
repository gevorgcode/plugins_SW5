<?php

/**
 * Class Shopware_Controllers_Frontend_Httppassverify
 */
class Shopware_Controllers_Frontend_Importserialcustom extends Enlight_Controller_Action{
        
    public function indexAction(){
        $SerialadminLoggedIn = $this->Request()->getCookie('SerialadminLogin');        
        if (!$SerialadminLoggedIn){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }
        if ($this->Request()->getParam('art_onumber') && $this->Request()->getParam('addcount')){
            $this->View()->assign('art_onumber', $this->Request()->getParam('art_onumber'));  
            $this->View()->assign('addcount', $this->Request()->getParam('addcount'));  
        }        
    } 
    
    public function serialloginAction(){
//        tpl
    }
    
    public function logoutAction(){
        $this->Response()->setCookie( 'SerialadminLogin', true, time()-3600, '/', null, true, true );
        $this->redirect([
            'action' => 'seriallogin',
        ]);
    }
    
    public function loginAction(){
        if (!$this->Request()->isPost()){
            return;
        }
        $login = $this->Request()->getParam('login');
        $password = $this->Request()->getParam('password');
        $login = trim($login);
        $login = stripslashes($login);
        $login = htmlspecialchars($login);
        
        $password = trim($password);
        $password = stripslashes($password);
        $password = htmlspecialchars($password);
        
        $user = Shopware()->Db()->fetchRow(
            'SELECT *
            FROM s_core_auth             
            WHERE s_core_auth.username = :username
            AND s_core_auth.roleID = 1',            
            ['username' => $login]
        );
        
        if (!$user){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
        }
        
        $dbPass = $user['password'];        
        $verypas = password_verify($password, $dbPass);
        // @vzg what function is this
        
        if ($verypas){
            $this->Response()->setCookie( 'SerialadminLogin', true, time()+3600, '/', null, true, true );
            $this->redirect([
                'action' => 'index',
            ]);
        }         
    }
    
    // @vzg this function is extremely long, and makes a lot of sql requests
    public function articleAction(){
        if (!$this->Request()->isPost()){
            return;
        }
        $SerialadminLoggedIn = $this->Request()->getCookie('SerialadminLogin');        
        if (!$SerialadminLoggedIn){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }
        
        $orderNumber = $this->Request()->getParam('art_onumber');
        $orderNumber = trim($orderNumber);
        $orderNumber = stripslashes($orderNumber);
        $orderNumber = htmlspecialchars($orderNumber);
        
        $s_articles_details = Shopware()->Db()->fetchRow(
            'SELECT *
            FROM s_articles_details             
            WHERE s_articles_details.ordernumber = :ordernumber',            
            ['ordernumber' => $orderNumber]
        );
        
        if (!$s_articles_details){
            $this->View()->assign('noMatchOrdernumber', $orderNumber);
            return;
        }
        
        $s_articles_esd = Shopware()->Db()->fetchRow(
            'SELECT *
            FROM s_articles_esd             
            WHERE s_articles_esd.articledetailsID = :articledetailsID',            
            ['articledetailsID' => $s_articles_details['id']]
        );
        
        if (!$s_articles_esd){
            $this->View()->assign('noEsdArticle', $s_articles_details['ordernumber']);
            return;
        }
        
        if ($s_articles_esd['serials'] != 1){
            $this->View()->assign('serialsDisabled', $s_articles_details['ordernumber']);
            return;
        }
        
        $name = Shopware()->Db()->fetchOne(
            'SELECT name
            FROM s_articles           
            WHERE s_articles.id = :id',            
            ['id' => $s_articles_details['articleID']]
        );
        
        //get all serials count by esdId
        $count_s_articles_esd_serials = Shopware()->Db()->fetchOne(
            'SELECT COUNT(*)
            FROM s_articles_esd_serials             
            WHERE s_articles_esd_serials.esdID = :esdID',            
            ['esdID' => $s_articles_esd['id']]
        );
        //select all used serials count by esdId
        $count_s_order_esd = Shopware()->Db()->fetchOne(
            'SELECT COUNT(*) 
            FROM s_order_esd             
            WHERE s_order_esd.esdID = :esdID
            AND s_order_esd.serialID > 0
            AND s_order_esd.serialID IN ( SELECT s_articles_esd_serials.id FROM `s_articles_esd_serials` )',            
            ['esdID' => $s_articles_esd['id']]
        );
        
        $freeSerials = $count_s_articles_esd_serials - $count_s_order_esd;
        
        $s_articles_esd_limits = Shopware()->Db()->fetchRow(
            'SELECT esd_serial_limit, esd_serial_limit_active
            FROM s_articles_esd_attributes             
            WHERE s_articles_esd_attributes.esdID = :esdID',            
            ['esdID' => $s_articles_esd['id']]
        );
        ///
        $s_articles_esd_attributes = Shopware()->Db()->fetchRow(
            'SELECT *
            FROM s_articles_esd_attributes             
            WHERE s_articles_esd_attributes.esdID = :esdID',            
            ['esdID' => $s_articles_esd['id']]
        );
        ///
        $article['allSerialCount'] = $count_s_articles_esd_serials;     
        $article['usedSerialCount'] = $count_s_order_esd;     
        $article['freeSerialCount'] = $freeSerials;     
        $article['ordernumber'] = $s_articles_details['ordernumber'];     
        $article['name'] = $name;     
        $article['esdId'] = $s_articles_esd['id'];     
        $article['s_articles_esd_limits'] = $s_articles_esd_limits;   
        $article['s_articles_esd_attributes'] = $s_articles_esd_attributes;     ///
               
        $this->View()->assign('article', $article);        
    }
    
    public function createserialAction(){
        if (!$this->Request()->isPost()){
            return;
        }
        $SerialadminLoggedIn = $this->Request()->getCookie('SerialadminLogin');        
        if (!$SerialadminLoggedIn){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }
        
        $params = $this->Request()->getParams();
        $orderNumber = $params['ordernumber'];
        $paramEsdID = $params['esdId'];
        $serials = $params['serials'];
        
        $articledetailsID = Shopware()->Db()->fetchOne(
            'SELECT id
            FROM s_articles_details             
            WHERE s_articles_details.ordernumber = :ordernumber',            
            ['ordernumber' => $orderNumber]
        );
        
        if (!$articledetailsID){            
            return;
        }
        
        $esdID = Shopware()->Db()->fetchOne(
            'SELECT id
            FROM s_articles_esd             
            WHERE s_articles_esd.articledetailsID = :articledetailsID',            
            ['articledetailsID' => $articledetailsID]
        );
        
        if ($paramEsdID != $esdID){
            return;
        }            
        $serialsArr = explode("\n", $serials);
        
        $i = 0;
        foreach ($serialsArr as $serial){            
            if (strlen($serial) > 3){
                $i++;
                Shopware()->Db()->insert('s_articles_esd_serials', [
                    'serialnumber' => $serial,
                    'esdID' => $esdID,
                ]);   
            }
        }
        
        $this->redirect([
            'action' => 'index',
            'art_onumber' => $orderNumber,
            'addcount' => $i,
        ]);                
    }
    
    public function setlimitAction(){
        if (!$this->Request()->isPost()){
            return;
        }
        $SerialadminLoggedIn = $this->Request()->getCookie('SerialadminLogin');        
        if (!$SerialadminLoggedIn){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }
        $params = $this->Request()->getParams();
        
        if($params['limit_active']){
            $active = 1;
        }else{
            $active = 0;
        }
        
        if($params['limit']){
            $limit = $params['limit'];
        }else{
            $limit = null;
        }
        
        if ($params['esdId']){
            $esd_attr_id = Shopware()->Db()->fetchOne(
                'SELECT id
                FROM s_articles_esd_attributes
                WHERE s_articles_esd_attributes.esdID = :esdID',             
                ['esdID' => $params['esdId']]
            );  
            if ($esd_attr_id){
                Shopware()->Db()->query(
                    'UPDATE s_articles_esd_attributes
                    SET s_articles_esd_attributes.esd_serial_limit = :limit,
                    s_articles_esd_attributes.esd_serial_limit_active = :active
                    WHERE s_articles_esd_attributes.esdID = :esdID',
                    ['limit' => $limit, 'active' => $active, 'esdID' => $params['esdId']]           
                ); 
            }else{
                Shopware()->Db()->query(
                    'INSERT INTO `s_articles_esd_attributes` (`esdID`, `esd_serial_limit`, `esd_serial_limit_active`) VALUES (?,?,?);',
                    [$params['esdId'], $limit, $active]           
                ); 
            }
            
        }
        
        $this->forward('article', null, null, ['art_onumber' => $params['art_onumber']]);
    }
        
    public function emailAction(){
        if (!$this->Request()->isPost()){
            return;
        }
        $SerialadminLoggedIn = $this->Request()->getCookie('SerialadminLogin');        
        if (!$SerialadminLoggedIn){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }
        $params = $this->Request()->getParams();
          
        if (($params['fromdate']) && ($params['todate']) && ($params['email'])){
            //date email
            $emails = Shopware()->Db()->fetchAll(
                'SELECT *
                FROM s_core_mails
                WHERE s_core_mails.mail_senddate >= :fromdate
                AND s_core_mails.mail_senddate <= :todate
                AND s_core_mails.mail_to = :mail_to
                ORDER BY id DESC LIMIT 0, 100',            
                ['fromdate' => $params['fromdate'], 'todate' => $params['todate'], 'mail_to' => $params['email'] ]
            );             
        }else if (($params['fromdate']) && ($params['todate']) && empty($params['email'])){
//            only date
            $emails = Shopware()->Db()->fetchAll(
                'SELECT *
                FROM s_core_mails
                WHERE s_core_mails.mail_senddate >= :fromdate
                AND s_core_mails.mail_senddate <= :todate
                ORDER BY id DESC LIMIT 0, 100',             
                ['fromdate' => $params['fromdate'], 'todate' => $params['todate'] ]
            );  
           
        }else{
            //last 20 emails
            $emails = Shopware()->Db()->fetchAll(
                'SELECT *
                FROM s_core_mails               
                ORDER BY id DESC LIMIT 0, 20'
            );            
        }        
        $this->View()->assign('emails', $emails);
        $this->View()->assign('params', $params);        
    }    
    
    public function setesdattrAction(){
        if (!$this->Request()->isPost()){
            return;
        }
        $SerialadminLoggedIn = $this->Request()->getCookie('SerialadminLogin');        
        if (!$SerialadminLoggedIn){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }
        $params = $this->Request()->getParams();
        
        if($params['additional_download_active']){
            $active = 1;
        }else{
            $active = 0;
        }        
        
        Shopware()->Db()->query(
            'UPDATE s_articles_esd_attributes
            SET s_articles_esd_attributes.text_1 = :text_1,
            s_articles_esd_attributes.text_2 = :text_2,
            s_articles_esd_attributes.text_3 = :text_3,
            s_articles_esd_attributes.text_4 = :text_4,
            s_articles_esd_attributes.file_1 = :file_1,
            s_articles_esd_attributes.file_2 = :file_2,
            s_articles_esd_attributes.file_3 = :file_3,
            s_articles_esd_attributes.file_4 = :file_4,
            s_articles_esd_attributes.additional_download_active = :active
            WHERE s_articles_esd_attributes.esdID = :esdID',
            ['text_1' => $params['text_1'], 'text_2' => $params['text_2'], 'text_3' => $params['text_3'], 'text_4' => $params['text_4'], 'file_1' => $params['file_1'], 'file_2' => $params['file_2'], 'file_3' => $params['file_3'], 'file_4' => $params['file_4'], 'active' => $active, 'esdID' => $params['esdId']]           
        ); 
        if (count($params) > 17){            
            Shopware()->Db()->query(
                'UPDATE s_articles_esd_attributes
                SET s_articles_esd_attributes.text_5 = :text_5,
                s_articles_esd_attributes.text_6 = :text_6,
                s_articles_esd_attributes.text_7 = :text_7,
                s_articles_esd_attributes.text_8 = :text_8,
                s_articles_esd_attributes.file_5 = :file_5,
                s_articles_esd_attributes.file_6 = :file_6,
                s_articles_esd_attributes.file_7 = :file_7,
                s_articles_esd_attributes.file_8 = :file_8                
                WHERE s_articles_esd_attributes.esdID = :esdID',
                ['text_5' => $params['text_5'], 'text_6' => $params['text_6'], 'text_7' => $params['text_7'], 'text_8' => $params['text_8'], 'file_5' => $params['file_5'], 'file_6' => $params['file_6'], 'file_7' => $params['file_7'], 'file_8' => $params['file_8'], 'esdID' => $params['esdId']]           
            ); 
        }
        $this->forward('article', null, null, ['art_onumber' => $params['art_onumber']]);
    }
}