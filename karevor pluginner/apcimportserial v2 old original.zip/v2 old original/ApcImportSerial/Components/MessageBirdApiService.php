<?php

namespace ApcImportSerial\Components;


class MessageBirdApiService {

    private $apiKey = null;

    private $originator = null;
    
    private $recipients = null;


    const BASE_URL = "https://rest.messagebird.com/messages"; // live

    public function __construct() {
        $config = Shopware()->Container()->get('shopware.plugin.config_reader')->getByPluginName('ApcImportSerial');
        $this->apiKey =  $config['api_key'];
        $this->originator =  $config['originator'];
        $this->recipients =  $config['recipients'];
    }
    
    //$articleOrdernumber, $freeSerialCount, $pluginDir
    public function sendMessage($art_onums, $pluginDir) {        
        if(empty($this->apiKey) || empty($this->originator) || empty($this->recipients)){
            return;
        }    
        $bodyPart = '';
        foreach ($art_onums as $item){
            $s = '';
            if($bodyPart){
                $s = ', ';
            }
            if ($item['sms']){
                $bodyPart = $bodyPart . $s . $item['sms'];
            }            
        }
        
        if ($bodyPart == ''){
            return;
        }
                
        $body = $this->originator . ' free serial count for article ' . $bodyPart . '.';
        
        $root = $pluginDir;
        $path = $root . '/Resources/lib/MessageBird/autoload.php';
        
        require_once($path);
        
        $MessageBird = new \MessageBird\Client($this->apiKey);
        $Message = new \MessageBird\Objects\Message();
        $Message->originator = $this->originator;
        $Message->recipients = $this->recipients;
        $Message->body = $body;

        $result = $MessageBird->messages->create($Message);
        
        return $result;
    }
}

?>





































