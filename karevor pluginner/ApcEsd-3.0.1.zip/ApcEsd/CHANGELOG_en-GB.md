# 3.0.1
- Improved the upload serial number by csv file
 
# 3.0.0
- Shopware 6 compatibility

# 2.0.4
* Fixed issue that the flow event is not triggered when upgrading from Shopware 6.4 to 6.5

# 2.0.3
* Re-release of version 2.0.1 with fixed error while compiling SCSS at Storefront. 

# 2.0.2
* Re-release of version 2.0.1 with fixed error while compiling SCSS at Storefront. 

# 2.0.1
* Fix error while compiling SCSS at Storefront

# 2.0.0
* Compatibility Shopware version 6.5.2.0+

# 1.6.3
* Fixed issue user can download the file without login.

# 1.6.2
* Added .epub and .mobi to the WhiteList of the media file extension

# 1.6.1
* Added CustomerAware and OrderAware to the Flow events to have a customer option.

# 1.6.0
* Compatibility Shopware version 6.4.18.0.
* Updated to send emails with Flow Builder.
* Fixed issues with the private & public files.
* Disabled send mail options within the plugin configuration.

# 1.5.5
* Fixed upload duplicate media file
* Fixed fileAccept to accept all filetypes

# 1.5.4
* Fixed error when applying promitional code

# 1.5.3
* Fixed to be able to sort the serials by Assigned client
* Fixed issue of show withdrawal
* Updated to show the default view is normal even if the video feature is enabled.
* Updated to can not be bought the product which has all serial keys was assigned.
* Added enable increase stock button when importing the serial keys.
* Added CDN compatibility

# 1.5.2
* Updated events file to compatible with the flow builder of shopware platform version >= 6.4.6.
* Fixed import of the core libraries
* fix the access to config variables in twig

# 1.5.1
* Added pagination for serials and added bulk delete selection.
* Bump lodash from 4.17.20 to 4.17.21 
* Missing compiled JS storefront files are now served

# 1.5.0
* Updated to remove the api version in the router

# 1.4.2
* Upgraded to be compatible with version 6.4
* Fixed send mail

# 1.4.1
* Fixed js compress file for version 1.4.0

# 1.4.0
* Added disable compression to zip file into the plugin config to be able to disable compression to zip file
* Add mail-template for the mail download with disable compression to zip file
* Fixed ESD order identification error
* Fixed upload media files

# 1.3.3
* Fixed getting line items of an ESD order
* Improved the language of `purchase date` column within account > downloads page

# 1.3.2
* Fixed to add return response for the download handling

# 1.3.1
* Fixed the issue can't finish order when the cart has a physical article and digital article

# 1.3.0
* ESD supported for the ESD video
* You're able to switch from ESD video to ESD normal
* Improved the template of showing ESD data in the account download page

# 1.2.14
* Improved download handling

# 1.2.13
* Removed `updateTo120` method of the update version, because it has been replaced with the migration 

# 1.2.12
* Fixed the error of using wrong class names and change the namespace and directory of events

# 1.2.11
* Fixed that the navigation isn't shown on the download account page
* Improved to send the ESD email by the business events
* Added the `Resend email download` and `Resend email serial` buttons to resend ESD email in the order detail pages
* we fixed an issue for corrupted .zip files on Windows

# 1.2.10
* Fixed the url in the mail template, change from url() to rawUrl() to get the sales channel domain
* Improved send mail feature, you can send the esd email to the buyer buy change the payment status to paid with the `Send email to customer` toggle is enable

# 1.2.9
* Fixed reload the remaining download data on Shopware >= v6.3.2.0, can update the remaining download after click download now

# 1.2.8
* Made a hotfix to send the download email on Shopware version 6.3.3.0

# 1.2.7
* fixed a bug with the general terms and condition checkbox during the checkout

# 1.2.6
* Updated to disable reload the page to get the remaining download data on Shopware version 6.3.2.0 >= 6.3.3.0

# 1.2.5
* show always revocation for digital downloads. Text Snippet Key is `apcEsd.checkout.confirmESD`

# 1.2.4
* fixed umlauts while downloading the .zip within the storefront

# 1.2.3
* added various filetypes to be able to upload also documents
* it's also possible to upload your very own .zip file

# 1.2.2
* fixed issue with terms of use

# 1.2.1
* added instant download badge on product detail
* added ESD withdrawal notice within checkout

# 1.2.0
* Added Download confirmation template
* Added Serial confirmation template
* Added Download Limitation of ESD
* Improved API documentation

# 1.1.0

* Added multiple file uploads
* Added order number to downloads table
* Fixed a bug within the Administration that an ESD does not load,
if you refresh the whole site directly

# 1.0.0

* First release in Store
