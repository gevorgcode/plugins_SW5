const { Context } = Shopware;

export default {
    inject: ['apcMediaService'],

    methods: {
        async updatePreviewData() {
            if (!this.currentTask) {
                this.existingMedia = null;
                this.suggestedName = '';
                return;
            }

            if (this.currentTask.plugin !== 'ESD') {
                this.$super('updatePreviewData');
                return;
            }

            // eslint-disable-next-line max-len
            this.existingMedia = await this.apcMediaService.getAdminSystemMedia(this.currentTask.fileName, this.currentTask.extension);
            const provided = await this.apcMediaService.provideName(this.currentTask.fileName, this.currentTask.extension);
            this.suggestedName = provided.fileName;
        },

        async renameFile(uploadTask) {
            if (uploadTask.plugin !== 'ESD') {
                this.$super('renameFile', uploadTask);
                return;
            }

            const newTask = { ...uploadTask };

            const { fileName } = await this.apcMediaService.provideName(uploadTask.fileName, uploadTask.extension);
            newTask.fileName = fileName;

            this.mediaService.addUpload(newTask.uploadTag, newTask);
            await this.mediaService.runUploads(newTask.uploadTag);
        },

        async replaceFile(uploadTask) {
            if (uploadTask.plugin !== 'ESD') {
                this.$super('replaceFile', uploadTask);
                return;
            }

            const newTarget = await this.apcMediaService.getAdminSystemMedia(uploadTask.fileName, uploadTask.extension);

            if (!newTarget) {
                return;
            }

            const oldTargetId = uploadTask.targetId;
            uploadTask.targetId = newTarget.id;

            this.mediaService.addUpload(uploadTask.uploadTag, uploadTask);

            await this.mediaService.runUploads(uploadTask.uploadTag);

            const oldTarget = await this.apcMediaService.getAdminSystemMediaById(oldTargetId);

            if (!oldTarget.hasFile) {
                await this.mediaRepository.delete(oldTargetId, Context.api);
            }

            await this.apcMediaService.getAdminSystemMediaById(uploadTask.targetId);
        },
    },
};
