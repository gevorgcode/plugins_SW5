import template from './apc-switch-esd-button.html.twig';

const { Mixin } = Shopware;
const { mapState, mapGetters } = Shopware.Component.getComponentHelper();

export default {
    template,

    inject: ['repositoryFactory'],

    mixins: [
        Mixin.getByName('notification'),
    ],

    props: {
        esdType: {
            type: String,
            required: true,
            default: 'normal',
        },
        label: {
            type: String,
            required: true,
            default: '',
        },
        confirmMessage: {
            type: String,
            required: true,
            default: '',
        },
    },

    data() {
        return {
            isShowConfirmModal: false,
            isLoading: false,
        };
    },

    computed: {
        ...mapGetters('swProductDetail', {
            isStoreLoading: 'isLoading',
        }),

        ...mapState('swProductDetail', [
            'product',
            'parentProduct',
        ]),

        productRepository() {
            return this.repositoryFactory.create('product');
        },
    },

    methods: {
        onConfirmChange() {
            this.isShowConfirmModal = true;
        },

        onCancelChange() {
            this.isShowConfirmModal = false;
        },

        async onChange() {
            this.isShowConfirmModal = false;
            this.isLoading = true;

            let routerName = 'apc.product.detail.esd';
            if (this.esdType === 'video') {
                routerName = 'apc.product.detail.esd.video';
            }

            await this.productRepository.save(this.product, Shopware.Context.api);
            await this.$router.push({ name: routerName, params: { id: this.$route.params.id } });
            // this.createNotificationSuccess({
            //     message: this.$tc('apc-esd.esdChange.messageChangeSuccess'),
            // });
        },
    },
};
