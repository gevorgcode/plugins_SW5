import template from './apc-product-detail-esd.html.twig';
import './apc-product-detail-esd.scss';

const { Mixin } = Shopware;
const { Criteria, EntityCollection } = Shopware.Data;
const { mapState, mapGetters } = Shopware.Component.getComponentHelper();

export default {
    template,

    inject: ['repositoryFactory', 'systemConfigApiService', 'apcMediaService'],

    mixins: [
        Mixin.getByName('notification'),
    ],

    data() {
        return {
            activeModal: '',
            fileAccept: '*/*',
            selectedItems: null,
            isLoading: true,
            isLoadedEsd: false,
            isShowDownloadMailAlert: false,
            isShowSerialMailAlert: false,
            isShowUploadProcessModal: false,
            uploadProcess: 0,
            fileNameUploading: '',
            isPublicMedia: true,
            isEsdVideo: false,
            isDisableZipFile: false,
        };
    },

    computed: {
        ...mapState('swProductDetail', [
            'product',
            'parentProduct',
        ]),

        ...mapGetters('swProductDetail', {
            isStoreLoading: 'isLoading',
        }),

        ...mapState('swProductEsdMedia', [
            'esdMedia',
            'isLoadedEsdMedia',
        ]),

        esdRepository() {
            return this.repositoryFactory.create('apc_product_esd');
        },

        esdMediaRepository() {
            return this.repositoryFactory.create('apc_product_esd_media');
        },

        mediaRepository() {
            return this.repositoryFactory.create('media');
        },

        mailTemplateRepository() {
            return this.repositoryFactory.create('mail_template');
        },

        mediaColumns() {
            return this.getMediaColumns();
        },

        productRepository() {
            return this.repositoryFactory.create('product');
        },

        productCriteria() {
            const criteria = new Criteria();

            criteria.getAssociation('media')
                .addSorting(Criteria.sort('position', 'ASC'));

            criteria.getAssociation('properties')
                .addSorting(Criteria.sort('name', 'ASC'));

            criteria.getAssociation('prices')
                .addSorting(Criteria.sort('quantityStart', 'ASC', true));

            criteria.getAssociation('tags')
                .addSorting(Criteria.sort('name', 'ASC'));

            criteria.getAssociation('seoUrls')
                .addFilter(Criteria.equals('isCanonical', true));

            criteria.getAssociation('crossSellings')
                .addSorting(Criteria.sort('position', 'ASC'))
                .getAssociation('assignedProducts')
                .addSorting(Criteria.sort('position', 'ASC'))
                .addAssociation('product')
                .getAssociation('product')
                .addAssociation('options.group');

            criteria
                .addAssociation('cover')
                .addAssociation('categories')
                .addAssociation('visibilities.salesChannel')
                .addAssociation('options')
                .addAssociation('configuratorSettings.option')
                .addAssociation('unit')
                .addAssociation('productReviews')
                .addAssociation('seoUrls')
                .addAssociation('mainCategories')
                .addAssociation('options.group')
                .addAssociation('customFieldSets')
                .addAssociation('featureSet')
                .addAssociation('cmsPage')
                .addAssociation('featureSet');

            criteria.getAssociation('manufacturer')
                .addAssociation('media');

            return criteria;
        },
    },

    watch: {
        isStoreLoading: {
            handler() {
                if (this.isStoreLoading === false) {
                    this.loadEsd();
                    this.loadMedia();
                }
            },
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        async createdComponent() {
            await this.fetchMediaConfig();
            await this.fetchEsdConfig();

            if (this.product.id !== this.parentProduct.id) {
                Shopware.State.commit('swProductEsdMedia/setIsLoadedEsdMedia', false);
                this.loadEsd();
                this.loadMedia();
            }
        },

        createMediaCollection() {
            return new EntityCollection('/esd-media', 'esd_media', Shopware.Context.api);
        },

        loadEsd() {
            if (!this.isStoreLoading && !this.isLoadedEsd) {
                /**
                 * We need to check if the extension esd exist,
                 * otherwise we would get an issue because it's undefined
                 */
                if (typeof this.product.extensions.esd === 'undefined') {
                    /* if not, create the relationship, so extensions.esd is available */
                    const esdExtension = this.esdRepository.create(this.context);
                    esdExtension.productId = this.product.id;
                    esdExtension.hasSerial = false;
                    this.product.extensions.esd = esdExtension;

                    this.productRepository.save(this.product, Shopware.Context.api).then(() => {
                        this.loadProduct();
                        this.isLoading = false;
                    });
                }
            }

            if (typeof this.product.extensions.esd !== 'undefined') {
                this.isLoadedEsd = true;
            }
        },

        loadProduct() {
            this.productRepository.get(this.product.id, Shopware.Context.api, this.productCriteria)
                .then((res) => {
                    Shopware.State.commit('swProductDetail/setProduct', res);
                });
        },

        loadMedia() {
            this.isLoading = true;
            const criteria = new Criteria();
            criteria.addAssociation('media');
            criteria.addFilter(Criteria.equals('esdId', this.product.extensions.esd.id));
            criteria.addFilter(Criteria.not('and', [Criteria.equals('mediaId', null)]));

            this.esdMediaRepository.search(criteria, Shopware.Context.api).then((esdMedia) => {
                this.product.extensions.esd.esdMedia = esdMedia;

                const esdMediaList = this.createMediaCollection();
                Shopware.State.commit('swProductEsdMedia/setEsdMedia', esdMediaList);
                esdMedia.forEach((item) => {
                    if (this.isEsdVideo && item.media.mediaType.name === 'VIDEO') {
                        // We don't show video in this list if the user enable esd video mode
                    } else {
                        Shopware.State.commit('swProductEsdMedia/addEsdMedia', item);
                    }
                });

                this.isLoading = false;
                Shopware.State.commit('swProductEsdMedia/setIsLoadedEsdMedia', true);
            });
        },

        getMediaColumns() {
            const columns = [
                {
                    property: 'media.fileName',
                    label: 'apc-esd.media.fileName',
                },
                {
                    property: 'fileType',
                    label: 'apc-esd.media.fileType',
                },
            ];

            if (this.isDisableZipFile) {
                columns.push({
                    property: 'downloadLimit',
                    label: 'apc-esd.media.downloadLimit',
                    inlineEdit: 'string',
                });
            }

            return columns;
        },

        async createEsdMediaAssoc(mediaItem) {
            this.isLoading = true;
            const esdMedia = this.esdMediaRepository.create(Shopware.Context.api);
            esdMedia.esdId = this.product.extensions.esd.id;
            esdMedia.mediaId = mediaItem.id;
            esdMedia.media = mediaItem;
            esdMedia.media.private = !this.isPublicMedia;

            await this.esdMediaRepository.save(esdMedia, Shopware.Context.api);

            this.product.extensions.esd.esdMedia.push(esdMedia);

            this.productRepository.save(this.product, Shopware.Context.api).then(() => {
                this.loadMedia();
                this.createNotificationSuccess({
                    message: this.$tc('apc-esd.notification.messageSaveSuccess'),
                });
            }).catch(() => {
                this.createNotificationError({
                    message: this.$tc('apc-esd.notification.messageSaveError'),
                });
            }).finally(() => {
                this.isLoading = false;
            });
        },

        async fetchMediaConfig() {
            await this.systemConfigApiService.getValues('ApcEsd.config')
                .then(response => {
                    this.isPublicMedia = response['ApcEsd.config.isPublicMedia'];
                });
        },

        getEsdMedia() {
            const esdMedia = this.createMediaCollection();
            Shopware.State.commit('swProductEsdMedia/setEsdMedia', esdMedia);
            this.product.extensions.esd.esdMedia.forEach((item) => {
                if (item.media && item.mediaId) {
                    if (this.isEsdVideo && item.media.mediaType.name === 'VIDEO') {
                        // We don't show video in this list if the user enable esd video mode
                    } else {
                        Shopware.State.commit('swProductEsdMedia/addEsdMedia', item);
                    }
                }
            });
        },

        async onSetMediaItem({ targetId }) {
            if (this.product.extensions.esd.esdMedia.some((esd) => esd.mediaId === targetId)) {
                return;
            }

            this.isLoading = true;
            if (this.product.extensions.esd.isNew) {
                await this.productRepository.save(this.product, Shopware.Context.api);
            }

            this.apcMediaService.getAdminSystemMediaById(targetId).then((updatedMedia) => {
                const media = this.createNewMedia(updatedMedia);
                this.createEsdMediaAssoc(media);
            });
        },

        createNewMedia(updatedMedia) {
            const media = this.mediaRepository.create();
            media.id = updatedMedia.id;
            media.fileExtension = updatedMedia.fileExtension;
            media.fileName = updatedMedia.fileName;
            media.fileSize = updatedMedia.fileSize;
            media.hasFile = updatedMedia.hasFile;
            media.mediaFolderId = updatedMedia.mediaFolderId;
            media.mimeType = updatedMedia.mimeType;
            media.private = updatedMedia.private;
            media.userId = updatedMedia.userId;

            return media;
        },

        onDeleteMediaItem(mediaId) {
            const foundIndex = this.product.extensions.esd.esdMedia.findIndex((esdMedia) => esdMedia.mediaId === mediaId);
            if (foundIndex < 0) {
                return;
            }

            this.product.extensions.esd.esdMedia[foundIndex].mediaId = null;
            this.getEsdMedia();
        },

        onDeleteSelectedMedia() {
            Object.values(this.selectedItems).forEach((item) => {
                if (item.media && item.media.id) {
                    this.onDeleteMediaItem(item.media.id);
                }
            });
        },

        onSelectionChanged(selection) {
            this.selectedItems = selection;
        },

        onMediaDropped(dropItem) {
            // to be consistent refetch entity with repository
            this.onSetMediaItem({ targetId: dropItem.id });
        },

        onShowProcess({ fileName, process }) {
            this.uploadProcess = process;
            if (process > 0 && process < 100) {
                this.isShowUploadProcessModal = true;
                this.fileNameUploading = fileName;
            } else {
                this.isShowUploadProcessModal = false;
                this.uploadProcess = 0;
                this.fileNameUploading = '';
            }
        },

        async fetchEsdConfig() {
            await this.systemConfigApiService.getValues('ApcEsd.config')
                .then(response => {
                    this.isEsdVideo = response['ApcEsd.config.isEsdVideo'];
                    this.isDisableZipFile = response['ApcEsd.config.isDisableZipFile'];
                });
        },

        onMediaUploadButtonOpenSidebar() {
            this.$root.$emit('esd-sidebar-toggle-open');
        },

        async onInlineEditSave(esdMedia) {
            await this.esdMediaRepository.save(esdMedia, Shopware.Context.api);
        },
    },
};
