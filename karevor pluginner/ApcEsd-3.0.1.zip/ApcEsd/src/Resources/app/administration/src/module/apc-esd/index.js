
Shopware.Component.register('apc-upload-listener', () => import('../../app/component/utils/apc-upload-listener'));
Shopware.Component.extend('apc-media-upload', 'sw-media-upload-v2', () => import('./component/apc-media-upload'));
Shopware.Component.register('apc-product-esd-form', () => import('./component/apc-product-esd-form'));
Shopware.Component.register('apc-esd-modal-serial', () => import('./component/apc-esd-modal-serial'));
Shopware.Component.register('apc-esd-serial-overview', () => import('./component/apc-esd-serial-overview'));
Shopware.Component.register('apc-esd-modal-csv', () => import('./component/apc-esd-modal-csv'));
Shopware.Component.register('apc-process-bar', () => import('./component/apc-process-bar'));
Shopware.Component.register('apc-switch-esd-button', () => import('./component/apc-switch-esd-button'));
Shopware.Component.override('sw-duplicated-media-v2', () => import('./component/apc-duplicated-media'));
Shopware.Component.override('sw-product-detail', () => import('./page/sw-product-detail'));
Shopware.Component.register('apc-product-detail-esd', () => import('./page/apc-product-detail-esd'));
Shopware.Component.register('apc-product-detail-esd-normal', () => import('./view/apc-product-detail-esd'));
Shopware.Component.register('apc-product-detail-esd-video', () => import('./view/apc-product-detail-esd-video'));

Shopware.Module.register('apc-esd-tab', {
    routeMiddleware(next, currentRoute) {
        if (currentRoute.name === 'sw.product.detail') {
            currentRoute.children.push({
                name: 'apc.product.detail.esd',
                path: '/sw/product/detail/:id/esd',
                component: 'apc-product-detail-esd-normal',
                meta: {
                    parentPath: 'sw.product.index',
                },
            });

            currentRoute.children.push({
                name: 'apc.product.detail.esd.video',
                path: '/sw/product/detail/:id/esd-video',
                component: 'apc-product-detail-esd-video',
                meta: {
                    parentPath: 'sw.product.index',
                },
            });
        }

        next(currentRoute);
    },
});
