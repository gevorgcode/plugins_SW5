import template from './apc-product-detail-esd.html.twig';

export default {
    template,

    metaInfo() {
        return {
            title: 'Custom',
        };
    },
};
