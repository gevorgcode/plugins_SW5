import ApcMediaService from '../../src/core/service/api/apc.media.api.service';

const Application = Shopware.Application;
Application.addServiceProvider('apcMediaService', (container) => {
    const initContainer = Application.getContainer('init');
    return new ApcMediaService(initContainer.httpClient, container.loginService);
});
