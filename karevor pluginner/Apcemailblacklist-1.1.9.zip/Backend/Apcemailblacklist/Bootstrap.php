<?php


use ShopwarePlugins\Apcemailblacklist\Subscriber\EMailForms;
use ShopwarePlugins\Apcemailblacklist\Component\Mailcrypter;

class Shopware_Plugins_Backend_Apcemailblacklist_Bootstrap extends Shopware_Components_Plugin_Bootstrap
{

    /**
     * Namespace for the snippets
     */
    protected $namespace;
    /**
     * Returns an array with the capabilities of the plugin.
     * @return array
     */
    // getCapabilities
    private $plugin_capabilities = array(
        'install' => true,
        'update' => true,
        'enable' => true,
        'secureUninstall' => true
    );

    /**
     * Internal helper function to get access to the entity manager.
     *
     * @return null
     */
    private function getManager()
    {
        if ($this->manager === null) {
            $this->manager = Shopware()->Models();
        }

        return $this->manager;
    }


    /**
     * After init event of the bootstrap class.
     *
     * The afterInit function registers the custom plugin models.
     */
    public function afterInit()
    {

        $this->registerNamespace();
        $this->registerCustomModels();
    }
    /**
     * function for register namespace
     *
     * @static
     */
    public function registerNamespace()
    {


        $this->Application()->Loader()->registerNamespace(
            'ShopwarePlugins\Apcemailblacklist',
            $this->Path()
        );


    }

    /**
     * Returns the current version of the plugin.
     * @return string
     */
    /**
     * Returns the version of plugin as string.
     *
     * @return string
     * @throws Exception
     */
    public function getVersion()
    {
        $info = json_decode(file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . 'plugin.json'), true);
        if ($info) {
            return $info['currentVersion'];
        } else {
            throw new Exception('The plugin has an invalid version file.');
        }
    }

    /**
     * Returns the version of plugin as string.
     *
     * @return string
     * @throws Exception
     */
    public function getInfos()
    {
        $info = json_decode(file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . 'plugin.json'), true);
        if ($info) {
            return $info;
        } else {
            throw new Exception('The plugin has an invalid version file.');
        }
    }

    /**
     *
     * @return array
     */
    public function getLabel()
    {
        return 'Email Blacklist für Shopware 5';
    }

    /**
     * Get Info version description from Plugin
     *
     * @public
     * @return array
     */
    /**
     * @return array
     */
    public function getInfo()
    {
        return array(
            'version' => $this->getVersion(),
            'label' => $this->getLabel(),
            'licence' => 'commercial',
            'autor' => 'Apceyes GmbH',
            'copyright' => 'Copyright @ 2011, Apceyes GmbH',
            'support' => 'http://www.apceyes.de',
            'link' => 'http://www.apceyes.de',
            'description' => file_get_contents($this->Path() . 'info.txt')
        );
    }



    /**
     * Install function of the plugin bootstrap.
     *
     * Registers all necessary components and dependencies.
     *
     */
    public function install()
    {
        try {


            $this->createDatabase();
            $this->createMenu();
            $this->createEvents();
            $this->createMyForm();


            return array(
                'success' => true,
                'invalidateCache' => array('backend')
            );


        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }


    /**
     * Registers the plugin controller event for the backend controller SwagFavorites
     */
    public function createEvents()
    {
        $this->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Backend_Apcemailblacklist',
            'onGetBackendController'
        );


        $this->subscribeEvent(
            'Enlight_Controller_Dispatcher_ControllerPath_Frontend_Pixvalidater',
            'onGetFrontendController'
        );


        $this->subscribeEvent(
            'Shopware_Modules_Admin_Login_Failure',
            'ShopwareModulesAdminLoginFailure'
        );

        $this->subscribeEvent(
            'Shopware_Modules_Admin_Login_Start',
            'ShopwareModulesAdminLoginStart'
        );

        $this->subscribeEvent(
            'Shopware_Modules_Admin_ValidateStep1_FilterResult',
            'ShopwareModulesAdminValidateStep1_FilterResult'
        );


        $this->subscribeEvent(
            'Shopware_Controllers_Frontend_Register::saveRegisterAction::replace',
            'afterSaveRegisterHook'
        );


        $this->subscribeEvent(
            'Theme_Compiler_Collect_Plugin_Javascript',
            'addJsFiles'
        );
        $this->subscribeEvent('Theme_Compiler_Collect_Plugin_Less', 'addLessFiles');

        /**
         *no description
         */
        $this->subscribeEvent(
            'Enlight_Controller_Action_PreDispatch',
            'onPreDispatch'
        );

        /**
         *no description
         */
        $this->subscribeEvent(
            'Enlight_Controller_Action_PostDispatch',
            'onPostDispatch'
        );

        $this->subscribeEvent(
            'Shopware_Controllers_Frontend_Newsletter::indexAction::before',
            'beforeNewsletterHook'
        );

        $this->subscribeEvent('Enlight_Controller_Front_StartDispatch', 'onStartDispatch');

    }


    public function beforeNewsletterHook(Enlight_Hook_HookArgs $args)
    {

        $request = $args->getSubject()->Request();
        $response = $args->getSubject()->Response();
        $view = $args->getSubject()->View();


        $config = Shopware()->Plugins()->Backend()->Apcemailblacklist()->Config()->toArray();


        if ($config['NEWSLETTERVALIDATE'] == '0') {


            $namespace = Shopware()->Snippets()->getNamespace('frontend/account/internalMessages');


            $sUnsubscribe = $args->getSubject()->Request()->getParam('sUnsubscribe');
            $data = $args->getSubject()->Request()->getPost();

            if (Shopware()->System()->_POST['subscribeToNewsletter'] == 1) {


                $checked = $this->CheckEmailBlacklist(Shopware()->System()->_POST['newsletter']);


                if ($checked['success'] == 'true') {


                    $view->_POST = Shopware()->System()->_POST->toArray();

                    $snippet = $namespace->get(
                        'EmailinNewsletterBlacklist',
                        "Leider ist das Anmelden beim Newsletter mit Email Adressen wie %s nicht m&ouml;glich.",
                        true
                    );
                    $error = sprintf($snippet, $checked['blacklistedemail']);


                    $view->emailStatus = [
                        'code' => 5,
                        'message' => $error,
                    ];


                }

            } else {

                $view->emailStatus = [
                    'code' => 0
                ];
            }

        }

    }


    public function afterSaveRegisterHook(Enlight_Hook_HookArgs $args)
    {

        $request = $args->getSubject()->Request();
        $response = $args->getSubject()->Response();
        $view = $args->getSubject()->View();


        $namespace = Shopware()->Snippets()->getNamespace('frontend/account/internalMessages');


        $_sAction = $args->getSubject()->Request()->getParam('sAction');

        $_sAction = $args->getSubject()->Request()->getParam('action');
        $_sTargetActions = $args->getSubject()->Request()->getParam('sTargetAction');
        $data = $args->getSubject()->Request()->getPost();


        $checked = $this->CheckEmailBlacklist($data['register']['personal']['email']);


        if ($checked['success'] == 'true') {
            //unset($data['register']['personal']['email']);
            unset($data['register']['personal']['password']);
            unset($data['register']['personal']['passwordConfirmation']);
            unset($data['register']['personal']['emailConfirmation']);


            $snippet = $namespace->get(
                'EmailinBlacklist',
                "Leider ist das Registrieren mit Email Adressen wie %s nicht m&ouml;glich.",
                true
            );
            $error = sprintf($snippet, $checked['blacklistedemail']);


            $serrors['email'] = $view->fetch('string:' . $error);

            $errors = [
                'personal' => $serrors,

            ];
            $subject = $args->getSubject();
            $subject->Request()->setParam('sAction', 'index');
            $subject->Request()->setParam('sTarget', 'account');
            $view->assign('errors', $errors);
            $view->assign($data);
            $args->getSubject()->forward('index', 'account');


        } else {


            // Setzen der Standardfunktion von sBasket
            $args->setReturn(
                $args->getSubject()->executeParent(
                    $args->getMethod(),
                    $args->getArgs()
                )
            );

        }


    }


    /**
     * Creates the plugin database tables over the doctrine schema tool.
     */
    private function createDatabase()
    {
        $em = $this->Application()->Models();
        $tool = new \Doctrine\ORM\Tools\SchemaTool($em);

        $classes = array(
            $em->getClassMetadata('Shopware\CustomModels\Apcemailblacklist\Emails')
        );

        try {
            $tool->createSchema($classes);
        } catch (\Doctrine\ORM\Tools\ToolsException $e) {

        }
    }

    /**
     * Creates the Favorites backend menu item.
     *
     * The Favorites menu item opens the listing for the SwagFavorites plugin.
     */
    public function createMenu()
    {

        try {
            $this->createMenuItem(array(
                'label' => 'Email Blacklist',
                'controller' => 'Apcemailblacklist',
                'class' => 'sprite-star',
                'action' => 'Index',
                'active' => 1,
                'position' => 100,
                'parent' => $this->Menu()->findOneBy(array('label' => 'Einstellungen'))
            ));

        } catch (Exception $e) {

        }

    }


    /**
     * Uninstall function of the plugin.
     * Fired from the plugin manager.
     * @return bool
     */
    public function uninstall()
    {
        $this->removeDatabaseTables();

        $this->secureUninstall();

        return true;
    }


// Remove only non-user related data.
    public function secureUninstall()
    {
        return true;
    }


    /**
     * Removes the plugin database tables
     */
    public function removeDatabaseTables()
    {
        $em = $this->Application()->Models();
        $tool = new \Doctrine\ORM\Tools\SchemaTool($em);

        $classes = array(
            $em->getClassMetadata('Shopware\CustomModels\Apcemailblacklist\Emails'),
        );

        $tool->dropSchema($classes);
    }

    /**
     * Returns the path to the controller.
     *
     * Event listener function of the Enlight_Controller_Dispatcher_ControllerPath_Backend_SwagFavorites
     * event.
     * Fired if an request will be root to the own Favorites backend controller.
     *
     * @return string
     */
    public function onGetBackendController()
    {


        $this->Application()->Snippets()->addConfigDir(
            $this->Path() . 'Snippets/'
        );
        $this->Application()->Template()->addTemplateDir(
            $this->Path() . 'Views/'
        );

        return $this->Path() . 'Controllers/Backend/Apcemailblacklist.php';
    }

    /**
     * Returns the path to the controller.
     *
     * Event listener function of the Enlight_Controller_Dispatcher_ControllerPath_Backend_SwagFavorites
     * event.
     * Fired if an request will be root to the own Favorites backend controller.
     *
     * @return string
     */
    public function onGetFrontendController()
    {


        $this->Application()->Snippets()->addConfigDir(
            $this->Path() . 'Snippets/'
        );
        $this->Application()->Template()->addTemplateDir(
            $this->Path() . 'Views/'
        );

        return $this->Path() . 'Controllers/Frontend/Pixvalidater.php';
    }

    /**
     * Event listener function of the Shopware_Modules_Admin_Login_Failure
     * event.
     * Fired if an request will be on Login Failure.
     *
     */

    public function ShopwareModulesAdminLoginFailure(Enlight_Event_EventArgs $arguments)
    {
        /** @var $sAdmin sAdmin */
        $sAdmin = $arguments->getSubject();

        $email = $arguments->getEmail();

        $password = $arguments->getPassword();

        $error = $arguments->getError();


    }

    /**
     * Event listener function of the Shopware_Modules_Admin_Login_Start
     * event.
     * Fired if an request will be on Login Start.
     *
     */
    public function ShopwareModulesAdminLoginStart(Enlight_Event_EventArgs $arguments)
    {
        /** @var $sAdmin sAdmin */
        $sAdmin = $arguments->getSubject();

        $post = $arguments->getPost();


    }

    /**
     * Event listener function of the Shopware_Modules_Admin_ValidateStep1_FilterResult
     * event.
     * Fired if an request will be on ValidateStep1.
     *
     * @return array
     */
    public function ShopwareModulesAdminValidateStep1_FilterResult(Enlight_Event_EventArgs $arguments)
    {

        $namespace = Shopware()->Snippets()->getNamespace('frontend/account/internalMessages');


        /** @var $sAdmin sAdmin */
        $sAdmin = $arguments->getSubject();

        $post = $arguments->getPost();

        /** @var boolean $edit */
        $edit = $arguments->getEdit();

        $sql = $arguments->getReturn();


        $checked = $this->CheckEmailBlacklist($post['email']);


        if ($checked['success'] == 'true') {

            $sql[1]['email'] = true;

            $snippet = $namespace->get(
                'EmailinBlacklist',
                "Leider ist das Registrieren mit Email Adressen wie %s nicht m&ouml;glich.",
                true
            );
            $sql[0][] = sprintf($snippet, $checked['blacklistedemail']);


        }


        return $sql;
    }


    /**
     * onPreDispatch  Pre Dispatch Eventlistener for Frontend
     * @public
     * @param Enlight_Event_EventArgs $args
     * @return void
     */
    public function onPreDispatch(Enlight_Event_EventArgs $args)
    {
        $request = $args->getSubject()->Request();
        $response = $args->getSubject()->Response();
        $view = $args->getSubject()->View();


        if ($response->isException() || $request->getModuleName() != 'frontend') {
            return;
        }


    }


    /**
     * is called after every action is finished
     *
     * @public
     * @param Enlight_Event_EventArgs $args
     * @return void
     */

    public function onPostDispatch(Enlight_Event_EventArgs $args)
    {


        /** @var $action Enlight_Controller_Action */
        $action = $args->getSubject();
        $request = $action->Request();
        $response = $action->Response();
        $view = $action->View();


        if (!$request->isDispatched()
            || $response->isException()
            || $request->getModuleName() != 'frontend'
            || !$view->hasTemplate()
        ) {
            return;
        }

        $this->Application()->Template()->addTemplateDir(
            $this->Path() . '/Views/'
        );

        $config = Shopware()->Plugins()->Backend()->Apcemailblacklist()->Config()->toArray();
        $view->assign(array("ebConfig" => $config));


    }


    /**
     * Check the Email
     * prueft die email in der blacklist
     * @public
     * @param Enlight_Event_EventArgs $args
     */
    public function CheckEmailBlacklist($user_email)
    {


        $dataSQL = "SELECT name FROM pix_emailblacklist";

        $emailblacklisted = Shopware()->Db()->fetchAll($dataSQL);


        if (is_array($emailblacklisted) and count($emailblacklisted) > 0) {

            $emailblacklisted_size = sizeof($emailblacklisted);


            for ($i = 0; $i < $emailblacklisted_size; $i++) {


                $emailblacklisted_current = trim($emailblacklisted[$i]['name']);
                if (stripos($user_email, $emailblacklisted_current) !== false) {


                    return array('success' => true, 'blacklistedemail' => $emailblacklisted_current);
                } else {

                }
            }

            return array('success' => false, 'blacklistedemail' => '');

        }
    }

    /**
     * UPDATE the Database Tables
     *
     * @static
     * @param Enlight_Event_EventArgs $args
     * @return bool
     */
    public function update($oldVersion)
    {

        $form = $this->Form();
        //Der Parameter $oldVersion gibt die Plugin-Version an, die vor dem Update
        //auf dem System installiert ist. Somit kann unterschieden werden, welche
        //Aktionen noch ausgeführt werden müssen.
        // Die neue Version des Plugins kann wie gewohnt über $this->getVersion() abgefragt werden.

        //Als Kontrollstruktur bietet sich hier eine Switch an.
        //Durch das Weglassen von breaks der switch k&ouml;nnen Sie
        //den Einstiegspunkt optimal definieren. Fangen Sie hierbei
        //mit der kleinsten Version an, in unserem Beispiel die Version 1.0.0
        switch ($oldVersion) {
            case '1.0.0':
            case '1.0.1':
            case '1.0.2':
            case '1.0.3':
            case '1.0.4':

                try {
                    Shopware()->Db()->query("ALTER TABLE `pix_emailblacklist` CHANGE `position` `position` INT( 11 ) NULL DEFAULT NULL;");
                } catch (Exception $e) {

                }


            case '1.0.5':
            case '1.0.6':
            case '1.0.7':


                $this->subscribeEvent(
                    'Shopware_Controllers_Frontend_Register::saveRegisterAction::replace',
                    'afterSaveRegisterHook'
                );


            case "1.0.8":

                $this->subscribeEvent(
                    'Theme_Compiler_Collect_Plugin_Javascript',
                    'addJsFiles'
                );
                $this->subscribeEvent('Theme_Compiler_Collect_Plugin_Less', 'addLessFiles');


                $form->setElement(
                    'select',
                    'AJAXVALIDATE',
                    array(
                        'label' => 'Email auch per Ajax prüfen',
                        'value' => '1',
                        'description' => 'Bei Ja, wird nach Eingabe der EMail auch per Ajax geprüft',
                        'required' => true,
                        'store' => array(
                            array('0', 'Ja'),
                            array('1', 'Nein')
                        ),
                        'scope' => Shopware\Models\Config\Element::SCOPE_SHOP
                    )
                );


            case "1.0.9":


                $this->subscribeEvent(
                    'Enlight_Controller_Dispatcher_ControllerPath_Frontend_Pixvalidater',
                    'onGetFrontendController'
                );


                /**
                 *no description
                 */
                $this->subscribeEvent(
                    'Enlight_Controller_Action_PreDispatch',
                    'onPreDispatch'
                );

                /**
                 *no description
                 */
                $this->subscribeEvent(
                    'Enlight_Controller_Action_PostDispatch',
                    'onPostDispatch'
                );

            case "1.1.0":


                $this->subscribeEvent(
                    'Shopware_Controllers_Frontend_Newsletter::indexAction::before',
                    'beforeNewsletterHook'
                );


                $form->setElement(
                    'select',
                    'NEWSLETTERVALIDATE',
                    array(
                        'label' => 'Email bei Newsletter prüfen',
                        'value' => '1',
                        'description' => 'Bei Ja, wird die EMail im Newsletter geprüft',
                        'required' => true,
                        'store' => array(
                            array('0', 'Ja'),
                            array('1', 'Nein')
                        ),
                        'scope' => Shopware\Models\Config\Element::SCOPE_SHOP
                    )
                );


            case "1.1.1":
            case "1.1.2":
            case "1.1.3":
            case "1.1.4":
            case "1.1.5":
            case "1.1.6":
            case "1.1.7":


            $this->subscribeEvent('Enlight_Controller_Front_StartDispatch', 'onStartDispatch');


            case "1.1.8":


                $form->setElement(
                    'select',
                    'FORMSVALIDATE',
                    array(
                        'label' => 'Email auch bei den Kontaktformular prüfen (BETA)',
                        'value' => 1,
                        'description' => 'Bei Ja, wird auch das Kontaktformular geprüft',
                        'required' => true,
                        'store' => array(
                            array(0, 'Ja'),
                            array(1, 'Nein')
                        ),
                        'scope' => Shopware\Models\Config\Element::SCOPE_SHOP
                    )
                );

                return true;

                break;


            default:
                //Die installierte Version entspricht weder 1.0.0 noch 1.0.1
                //Aus diesem Grund wird dem Plugin-Manaager mitgeteilt,
                //dass das Update fehlgeschlagen ist.
                return false;
        }

        //Nachdem das Update durchgelaufen ist muss true zurückgegeben
        //werden, um das Update abzuschliessen
        return true;
    }

    /**
     * Provide the file collection for js files
     *
     * @param Enlight_Event_EventArgs $args
     * @return \Doctrine\Common\Collections\ArrayCollection
     */
    public function addJsFiles(Enlight_Event_EventArgs $args)
    {
        $jsFiles = array(__DIR__ . '/Views/frontend/_public/src/js/emailblacklist.js');

        return new Doctrine\Common\Collections\ArrayCollection($jsFiles);
    }

    /**
     * Provide the file collection for less
     */
    public function addLessFiles(Enlight_Event_EventArgs $args)
    {
        $less = new \Shopware\Components\Theme\LessDefinition(

            array(),

            array(
                __DIR__ . '/Views/frontend/_public/src/less/all.less'
            ),


            __DIR__
        );

        return new Doctrine\Common\Collections\ArrayCollection(array($less));
    }


    /**
     * Creates and stores the config form.
     * absolute Url
     * Domain
     *
     * @public
     * @return void
     */
    protected function createMyForm()
    {


        $form = $this->Form();


        $form->setElement(
            'select',
            'AJAXVALIDATE',
            array(
                'label' => 'Email auch per Ajax prüfen',
                'value' => '1',
                'description' => 'Bei Ja, wird nach Eingabe der EMail auch per Ajax geprüft',
                'required' => true,
                'store' => array(
                    array('0', 'Ja'),
                    array('1', 'Nein')
                ),
                'scope' => Shopware\Models\Config\Element::SCOPE_SHOP
            )
        );


        $form->setElement(
            'select',
            'NEWSLETTERVALIDATE',
            array(
                'label' => 'Email bei Newsletter prüfen',
                'value' => '1',
                'description' => 'Bei Ja, wird die EMail im Newsletter geprüft',
                'required' => true,
                'store' => array(
                    array('0', 'Ja'),
                    array('1', 'Nein')
                ),
                'scope' => Shopware\Models\Config\Element::SCOPE_SHOP
            )
        );

        $form->setElement(
            'select',
            'FORMSVALIDATE',
            array(
                'label' => 'Email auch bei den Kontaktformular prüfen  (BETA)',
                'value' => 1,
                'description' => 'Bei Ja, wird auch das Kontaktformular geprüft',
                'required' => true,
                'store' => array(
                    array(0, 'Ja'),
                    array(1, 'Nein')
                ),
                'scope' => Shopware\Models\Config\Element::SCOPE_SHOP
            )
        );

    }


    /**
     * registers events via subscribers
     */
    public function onStartDispatch()
    {

        $container = $this->get('service_container');
        $this->registerCustomModels();
        $this->registerMyTemplateDir();

        $subscribers = [


            new EMailForms($container, $this->Path())
        ];

        foreach ($subscribers as $subscriber) {
            $this->get('events')->addSubscriber($subscriber);
        }


    }


    /**
     * register the Plugin Template Directory
     *
     * @protected
     * @return void
     */
    protected function registerMyTemplateDir()
    {

        $this->Application()->Snippets()->addConfigDir(
            $this->Path().'Snippets/'
        );


        $this->Application()->Template()->addTemplateDir($this->Path().'/Views/');
    }


}
