<?php
namespace ShopwarePlugins\Apcemailblacklist\Subscriber;

use Enlight\Event\SubscriberInterface;
use Enlight_Event_EventArgs;
use Enlight_Event_EventArgs as EventArgs;
use Shopware\Components\DependencyInjection\Container as DIContainer;
use \Shopware_Plugins_Frontend_Apcemailblacklist_Bootstrap as Pluginbootstrap;
use ShopwarePlugins\Apcemailblacklist\Component\Mailcrypter;

class EMailForms implements SubscriberInterface
{
    /**
     * @var DIContainer
     */
    private $container;


    /**
     * Path to the plugin directory
     */
    protected $path;

    /**
     * @param DIContainer $container
     */
    public function __construct(
        DIContainer $container,
        $path
    )
    {
        $this->container = $container;
        $this->path = $path;
    }

    /**
     * {@inheritdoc}
     */
    public static function getSubscribedEvents()
    {
        return [

            'Shopware_Controllers_Frontend_Forms_commitForm_Mail' => 'commitFormMail',
            'Enlight_Controller_Action_PreDispatch' => 'onPreDispatch',
            'Enlight_Controller_Action_PostDispatch' => 'onPostDispatch'
        ];
    }


    /**
     * onPreDispatch  Pre Dispatch Eventlistener for Frontend
     * @public
     * @param Enlight_Event_EventArgs $args
     * @return void
     */
    public function commitFormMail(Enlight_Event_EventArgs $args)
    {


        /** @var \Enlight_Components_Mail $mail */
        $mail = $args->getReturn();
        $emailfromCustomer = $mail->getReplyTo();
        $request = $args->getSubject()->Request();
        $subject = $args->getSubject();
        $shop = Shopware()->Plugins()->Backend()->Apcemailblacklist()->Application()->Shop();
        $config = Shopware()->Container()->get('shopware.plugin.config_reader')->getByPluginName('Apcemailblacklist',
            $shop);


        if ($config['FORMSVALIDATE'] != 1) {


            $id = $request->getParam('sFid') ?: $request->getParam('id');
            $formId = (int)$id;

            if (!empty($emailfromCustomer)) {


                $namespace = Shopware()->Snippets()->getNamespace('frontend/account/internalMessages');

                $checked = $this->CheckEmailBlacklist($emailfromCustomer);


                $errors = [
                    'email' => false,
                    'emailConfirmation' => true,
                ];

                if ($checked['success'] == 'true') {


                    $snippet = $namespace->get(
                        'EmailinBlacklist',
                        "Leider ist das Registrieren mit Email Adressen wie %s nicht m&ouml;glich.",
                        true
                    );


                    $errors = [
                        'email' => sprintf($snippet, $checked['blacklistedemail']),
                        'emailConfirmation' => false,
                    ];


                    $test = new Mailcrypter();
                    $reinsert = '#' . $checked['blacklistedemail'] . '#';
                    $created = $test->encryptData($reinsert);
                    $ocreated = $created;


                    $subject->redirect(
                        [
                            'controller' => 'forms',
                            'action' => 'index',
                            'sFid' => $formId,
                            'success' => 0,
                            'blerrors' => $ocreated
                        ]
                    );
                    $subject->Response()->sendResponse();

                    exit();


                }


            }

        }


    }

    /**
     * Check the Email
     * prueft die email in der blacklist
     * @public
     * @param Enlight_Event_EventArgs $args
     */
    public function CheckEmailBlacklist($user_email)
    {




        $dataSQL = "SELECT name FROM pix_emailblacklist";

        $emailblacklisted = Shopware()->Db()->fetchAll($dataSQL);


        if (is_array($emailblacklisted) and count($emailblacklisted) > 0) {

            $emailblacklisted_size = sizeof($emailblacklisted);


            for ($i = 0; $i < $emailblacklisted_size; $i++) {


                $emailblacklisted_current = trim($emailblacklisted[$i]['name']);
                if (stripos($user_email, $emailblacklisted_current) !== false) {


                    return array('success' => true, 'blacklistedemail' => $emailblacklisted_current);
                } else {

                }
            }

            return array('success' => false, 'blacklistedemail' => '');

        }
    }

    /**
     * onPreDispatch  Pre Dispatch Eventlistener for Frontend
     * @public
     * @param Enlight_Event_EventArgs $args
     * @return void
     */
    public function onPreDispatch(Enlight_Event_EventArgs $args)
    {



        $controller = $args->get('subject');
        $view = $controller->View();




        $view->addTemplateDir(
            $this->path.'/Views/'
        );

    }

    /**
     * is called after every action is finished
     *
     * @public
     * @param Enlight_Event_EventArgs $args
     * @return void
     */

    public function onPostDispatch(Enlight_Event_EventArgs $args)
    {




        /** @var $action Enlight_Controller_Action */
        $action = $args->getSubject();
        $request = $action->Request();
        $response = $action->Response();
        $view = $action->View();
        $namespace = Shopware()->Snippets()->getNamespace('frontend/account/internalMessages');


        if (!$request->isDispatched()
            || $response->isException()
            || $request->getModuleName() != 'frontend'
            || !$view->hasTemplate()
        ) {
            return;
        }


        $shop = Shopware()->Plugins()->Backend()->Apcemailblacklist()->Application()->Shop();
        $config = Shopware()->Container()->get('shopware.plugin.config_reader')->getByPluginName('Apcemailblacklist',
            $shop);


        if ($config['FORMSVALIDATE'] != 1) {

            Shopware()->Template()->addTemplateDir(
                $this->path . '/Views/'
            );
            $blerrors = $request->getParam('blerrors');
            if ($blerrors) {
                $snippet = $namespace->get(
                    'EmailinBlacklist',
                    "Leider ist das Registrieren mit Email Adressen wie %s nicht m&ouml;glich.",
                    true
                );


                $test = new Mailcrypter();
                $_passphrase = trim($test->decryptData($blerrors));
                $_passphrase = str_replace('#', '', $_passphrase);
                $errors = sprintf($snippet, $_passphrase);

                $view->blerrors = $errors;
            }
            

        }

        $view->emailblacklistconfig = $config;

    }


    /**
     * register the Plugin Template Directory
     *
     * @protected
     * @return void
     */
    protected function registerMyTemplateDir()
    {

        Shopware()->Snippets()->addConfigDir(
            $this->path.'Snippets/'
        );




        Shopware()->Template()->addTemplateDir(
            $this->path .'/Views/'
        );
    }



}
