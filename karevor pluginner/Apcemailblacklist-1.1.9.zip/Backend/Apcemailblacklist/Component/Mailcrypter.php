<?php

namespace ShopwarePlugins\Apcemailblacklist\Component;

class Mailcrypter {

    const CIPHER_AES = 'aes-128-cbc';

    /**
     * @param $session_id
     * @return string
     */
    public function encrypt($session_id) {
        $key = $this->_getSalt();
        $iv = $this->_getIv();
        $cipherText = openssl_encrypt($session_id, self::CIPHER_AES, $key, $options=OPENSSL_RAW_DATA, $iv);


        $encryptedId = strtr(base64_encode($cipherText), '+/=', '-_,');
        return $encryptedId;
    }

    public function encryptData($input) {
        $output = $this->encrypt($input);
        return $output;
    }

    public function decryptData($input) {
        $input =  strtr($input, '-_,', '+/=');
        $output = $this->decrypt($input);
        return $output;
    }

    /**
     * @param $encryptedSessionId
     * @return string
     */
    public function decrypt($encryptedSessionId) {
        $key = $this->_getSalt();
        $iv = $this->_getIv();
        $decoded = base64_decode($encryptedSessionId, TRUE);
        $decryptedId = openssl_decrypt($decoded, self::CIPHER_AES, $key, $options=OPENSSL_RAW_DATA, $iv);
        $decrypted_id = rtrim($decryptedId, '\0');
        return $decrypted_id;
    }

    public function _getIv() {
        $ivlen = openssl_cipher_iv_length(self::CIPHER_AES);
        return substr(md5($this->_getSalt()), 0, $ivlen);


    }

    public function _getSalt() {
        return $this->GetHashSalt();
    }

    private function GetHashSalt() {

        return hash('sha256', "DJVcwr9fhEWIUe04Wkdsdfsid546754EdfvsWg6efflBdfE")  ;
    }

}