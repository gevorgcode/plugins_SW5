<?php
/**
 * Shopware 4.0
 * Copyright © 2012 shopware AG
 *
 * According to our dual licensing model, this program can be used either
 * under the terms of the GNU Affero General Public License, version 3,
 * or under a proprietary license.
 *
 * The texts of the GNU Affero General Public License with an additional
 * permission and of our proprietary license can be found at and
 * in the LICENSE file you have received along with this program.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * "Shopware" is a registered trademark of shopware AG.
 * The licensing of the program under the AGPLv3 does not imply a
 * trademark license. Therefore any rights, title and interest in
 * our trademarks remain entirely with us.
 *
 * @category   Shopware
 * @copyright  Copyright (c) 2012, shopware AG (http://www.shopware.de)
 * @author shopware AG
 */

namespace Shopware\CustomModels\Apcemailblacklist;

use Shopware\Components\Model\ModelEntity,
    Doctrine\ORM\Mapping AS ORM,
    Symfony\Component\Validator\Constraints as Assert,
    Doctrine\Common\Collections\ArrayCollection;


/**
 * Shopware\CustomModels\Apcemailblacklist\Emails
 *
 * @ORM\Table(name="pix_emailblacklist")
 * @ORM\Entity(repositoryClass="Repository")
 */
class Emails extends ModelEntity
{
    /**
     * @var integer $id
     *
     * @ORM\Column(name="id", type="integer", precision=0, scale=0, nullable=false, unique=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string $name
     *
     * @ORM\Column(name="name", type="string", length=100, precision=0, scale=0, nullable=false, unique=false)
     */
    private $name;

    /**
     * @var integer $position
     *
     * @ORM\Column(name="position", type="integer", precision=0, scale=0, nullable=true, unique=false)
     */
    private $position;

    /**
     * @var \DateTime $created
     *
     * @ORM\Column(name="created", type="datetime", precision=0, scale=0, nullable=false, unique=false)
     */
    private $created;

    /**
     * @var string $comment
     *
     * @ORM\Column(name="comment", type="text", precision=0, scale=0, nullable=false, unique=false)
     */
    private $comment;

    
	/**
     * Construct of the actually Class
     */
    public function __construct()
    {
         
    }

    /**
     * Get id from EMail Database
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name from EMail Database
     *
     * @param string $name
     * @return Favorite
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * Get name from EMail Database
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set position from EMail Database
     *
     * @param integer $position
     * @return Favorite
     */
    public function setPosition($position)
    {
        $this->position = (int)$position;
        return $this;
    }

    /**
     * Get position from EMail Database
     *
     * @return integer
     */
    public function getPosition()
    {
        return (int)$this->position;
    }

    /**
     * Set created from EMail Database
     *
     * @param \DateTime $created
     * @return Favorite
     */
    public function setCreated($created)
    {
        $this->created = $created;
        return $this;
    }

    /**
     * Get created from EMail Database
     *
     * @return \DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * Set comment from EMail Database
     *
     * @param string $comment
     * @return Favorite
     */
    public function setComment($comment)
    {
        $this->comment = $comment;
        return $this;
    }

    /**
     * Get comment from EMail Database
     *
     * @return string
     */
    public function getComment()
    {
        return $this->comment;
    }

      
}