<?php
/**
 * Shopware 4.0
 * Copyright © 2012 shopware AG
 *
 * According to our dual licensing model, this program can be used either
 * under the terms of the GNU Affero General Public License, version 3,
 * or under a proprietary license.
 *
 * The texts of the GNU Affero General Public License with an additional
 * permission and of our proprietary license can be found at and
 * in the LICENSE file you have received along with this program.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * "Shopware" is a registered trademark of shopware AG.
 * The licensing of the program under the AGPLv3 does not imply a
 * trademark license. Therefore any rights, title and interest in
 * our trademarks remain entirely with us.
 *
 * @category   Shopware
 * @copyright  Copyright (c) 2012, shopware AG (http://www.shopware.de)
 * @author shopware AG
 */
namespace Shopware\CustomModels\Apcemailblacklist;
use Shopware\Components\Model\ModelRepository;

/**
 * Repository for the customer model (Shopware\CustomModels\Apcemailblacklist).
 * <br>
 * The dispatch models accumulates all data needed for a specific repository
 *
 */
class Repository extends ModelRepository
{
    /**
     * Creates an query builder object which selects a list of favorites.
     *
     * @param $filter
     * @param $sort
     * @param $offset
     * @param $limit
     *
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function getListQueryBuilder($filter, $sort, $offset, $limit)
    {
		
		 
        $builder = $this->getEntityManager()->createQueryBuilder();
		
		$builder->select(array(
			'apcemailblacklist',
            'apcemailblacklist.id as id',
            'apcemailblacklist.name as name',
            'apcemailblacklist.position as position',
            'apcemailblacklist.created as created',
            'apcemailblacklist.comment as comment'
    ));
	
        $builder->from($this->getEntityName(), 'apcemailblacklist') ;
				
			//echo $builder->getQuery()->getSQL();

 	

        if (!empty($filter)) {
            $builder->addFilter($filter);
        }
        if (!empty($sort)) {
            $builder->addOrderBy($sort);
        }

        $builder->setFirstResult($offset)
                ->setMaxResults($limit);

        return $builder;
    }

    /**
     * Creates an query builder object which selects the data for a single favorite.
     * @param $favoriteId
     *
     * @return \Doctrine\ORM\QueryBuilder
     */
    public function getOneQueryBuilder($favoriteId) {
        $builder = $this->getEntityManager()->createQueryBuilder();
        $builder->select(array('emailblacklist' ))
                ->from($this->getEntityName(), 'emailblacklist') 
                ->where('emailblacklist.id = :id')
                ->setParameters(array('id' => $favoriteId));

        $builder->setFirstResult(0)
                ->setMaxResults(1);

        return $builder;
    }

}