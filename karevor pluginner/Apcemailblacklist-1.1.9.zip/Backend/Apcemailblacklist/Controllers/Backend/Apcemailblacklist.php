<?php
/**
 * Shopware 4.0
 * Copyright © 2012 shopware AG
 *
 * According to our dual licensing model, this program can be used either
 * under the terms of the GNU Affero General Public License, version 3,
 * or under a proprietary license.
 *
 * The texts of the GNU Affero General Public License with an additional
 * permission and of our proprietary license can be found at and
 * in the LICENSE file you have received along with this program.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * "Shopware" is a registered trademark of shopware AG.
 * The licensing of the program under the AGPLv3 does not imply a
 * trademark license. Therefore any rights, title and interest in
 * our trademarks remain entirely with us.
 *
 * @category   Shopware
 * @copyright  Copyright (c) 2012, shopware AG (http://www.shopware.de)
 * @author shopware AG
 */

class Shopware_Controllers_Backend_Apcemailblacklist extends Shopware_Controllers_Backend_ExtJs
{
    protected $repository = null;

    /**
	 * GET the Repository from Plugin
     * @return \Shopware\CustomModels\Apcemailblacklist\Repository
     */
    public function getRepository() {
        if ($this->repository === null) {
            $this->repository = Shopware()->Models()->getRepository(
                'Shopware\CustomModels\Apcemailblacklist\Emails'
            );
        }
        return $this->repository;
    }

    /**
     * Controller action which can be called over an ajax request.
     * This function can be used to get a sorted and ordered list of defined favorites.
     */
    public function getListAction() {
        $this->View()->assign(
            $this->getList(
                $this->Request()->getParam('filter'),
                $this->Request()->getParam('sort'),
                $this->Request()->getParam('start'),
                $this->Request()->getParam('limit')
            )
        );
    }

    /**
     * Controller action which can be called over an ajax request.
     * This function can be used to create a new favorite.
     */
    public function createEmailAction() {
        $this->View()->assign(
            $this->saveEmail($this->Request()->getParams())
        );
    }

    /**
     * Controller action which can be called over an ajax request.
     * This function can be used to update an existing favorite.
     */
    public function updateEmailAction() {
        $this->View()->assign(
            $this->saveEmail($this->Request()->getParams())
        );
    }

    /**
     * Controller action which can be called over an ajax request.
     * This function can be used to remove a defined favorite.
     */
    public function deleteEmailAction() {
        $this->View()->assign(
            $this->deleteEmail(
                $this->Request()->getParam('id')
            )
        );
    }

    /**
     * Internal helper function which selects an filtered and sorted offset of
     * favorites.
     * @param $filter
     * @param $sort
     * @param $offset
     * @param $limit
     *
     * @return array
     */
    protected function getList($filter, $sort, $offset, $limit) {
        $builder = $this->getRepository()->getListQueryBuilder(
            $filter, $sort, $offset, $limit
        );
        $query = $builder->getQuery();

        $query->setHydrationMode(
            \Doctrine\ORM\AbstractQuery::HYDRATE_ARRAY
        );

        $paginator = new \Doctrine\ORM\Tools\Pagination\Paginator($query);

        return array(
            'success' => true,
            'total'   => $paginator->count(),
            'data'    => $paginator->getIterator()->getArrayCopy()
        );
    }

    /**
     * Internal helper function which removes the existing favorite, which identified over
     * the passed favorite id.
     *
     * @param $favoriteId
     *
     * @return array
     */
    protected function deleteEmail($favoriteId) {
        if (empty($favoriteId)) {
            return array('success' => false, 'error' => 'No id passed');
        }

        $favorite = Shopware()->Models()->find(
            '\Shopware\CustomModels\Apcemailblacklist\Emails',
            (int) $favoriteId
        );

        if (!($favorite instanceof \Shopware\CustomModels\Apcemailblacklist\Emails)) {
            return array(
                'success' => false,
                'error'   => "The passed id '" . $favoriteId . " don't exist"
            );
        }

        try {
            Shopware()->Models()->remove($favorite);
            Shopware()->Models()->flush();
            return array('success' => true);
        } catch (Exception $e) {
            return array(
                'success' => true,
                'error'   => $e->getMessage()
            );
        }
    }

    /**
     * Internal helper function which can be used to save a new or existing favorite.
     * If the data parameter contains the id field, the function updates an existing favorite,
     * which identified over the id.
     * @param $data
     *
     * @return array
     */
    protected function saveEmail($data) {
        try {
			
			if (empty($data['id'])) {
			    $sql = "SELECT max(position)+1 FROM pix_emailblacklist "; 
            	$data['position'] = Shopware()->Db()->fetchOne($sql );
			
			}
            $favorite = new \Shopware\CustomModels\Apcemailblacklist\Emails();
            if (!empty($data['id'])) {
                 $favorite = Shopware()->Models()->find(
                    '\Shopware\CustomModels\Apcemailblacklist\Emails',
                    (int) $data['id']
                );
            }

            if (!($favorite instanceof \Shopware\CustomModels\Apcemailblacklist\Emails)) {
                return array(
                    'success' => false,
                    'error'   => "The passed id '" . $data['id'] . " don't exist"
                );
            }
            
            $favorite->fromArray($data);

            Shopware()->Models()->persist($favorite);
            Shopware()->Models()->flush();

            $data = $this->getEmail(
                $favorite->getId(),
                \Doctrine\ORM\AbstractQuery::HYDRATE_ARRAY
            );
            return array(
                'success' => true,
                'data' => $data
            );
        } catch (Exception $e) {

            $error = $e->getMessage();
            return array(
                'success' => false,
                'data'    => $data,
                'error'   => $error
            );
        }
    }

    /**
     * Helper function to get a single favorite object.
     *
     * @param     $favoriteId
     * @param int $hydrationMode
     *
     * @return mixed
     */
    protected function getEmail($favoriteId, $hydrationMode = \Doctrine\ORM\AbstractQuery::HYDRATE_OBJECT)
    {
        $builder = $this->getRepository()->getOneQueryBuilder($favoriteId);
        return $builder->getQuery()->getOneOrNullResult($hydrationMode);
    }

     

}