<?php
/**
 * Shopware 5
 * Copyright (c) shopware AG
 *
 * According to our dual licensing model, this program can be used either
 * under the terms of the GNU Affero General Public License, version 3,
 * or under a proprietary license.
 *
 * The texts of the GNU Affero General Public License with an additional
 * permission and of our proprietary license can be found at and
 * in the LICENSE file you have received along with this program.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * "Shopware" is a registered trademark of shopware AG.
 * The licensing of the program under the AGPLv3 does not imply a
 * trademark license. Therefore any rights, title and interest in
 * our trademarks remain entirely with us.
 */

use Shopware\Bundle\AccountBundle\Form\Account\AddressFormType;
use Shopware\Bundle\AccountBundle\Form\Account\PersonalFormType;
use Shopware\Bundle\AccountBundle\Service\RegisterServiceInterface;
use Shopware\Bundle\StoreFrontBundle\Struct\ShopContextInterface;
use Shopware\Components\Captcha\Exception\CaptchaNotFoundException;
use Shopware\Models\Customer\Address;
use Shopware\Models\Customer\Customer;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormInterface;

class Shopware_Controllers_Frontend_Pixvalidater extends Enlight_Controller_Action
{
    protected $repository = null;


    /**
     * Will be called from the dispatcher before an action is processed
     */
    public function preDispatch()
    {
        $this->View()->setScope(Enlight_Template_Manager::SCOPE_PARENT);
    }

    /**
     * GET the Repository from Plugin
     * @return \Shopware\CustomModels\Apcemailblacklist\Repository
     */
    public function getRepository()
    {
        if ($this->repository === null) {
            $this->repository = Shopware()->Models()->getRepository(
                'Shopware\CustomModels\Apcemailblacklist\Emails'
            );
        }

        return $this->repository;
    }


    public function ajaxValidateFormEmailAction()
    {
        Shopware()->Plugins()->Controller()->ViewRenderer()->setNoRender();

        $data = $this->getPostData();

        $namespace = Shopware()->Snippets()->getNamespace('frontend/account/internalMessages');

        $checked = $this->CheckEmailBlacklist($data['email']);


        $errors = [
            'email' => false,
            'emailConfirmation' => true
        ];

        if ($checked['success'] == 'true') {


            $snippet = $namespace->get(
                'EmailinBlacklist',
                "Leider ist das Registrieren mit Email Adressen wie %s nicht m&ouml;glich.",
                true
            );


            $errors = [
                'email' => sprintf($snippet, $checked['blacklistedemail']),
                'emailConfirmation' => false,
            ];


        }

        $this->Response()->setHeader('Content-type', 'application/json', true);
        $this->Response()->setBody(json_encode($errors));

    }

    public function ajaxValidateEmailAction()
    {
        Shopware()->Plugins()->Controller()->ViewRenderer()->setNoRender();

        $data = $this->getPostData();

        $namespace = Shopware()->Snippets()->getNamespace('frontend/account/internalMessages');

        $checked = $this->CheckEmailBlacklist($data['register']['personal']['email']);


        $errors = [
            'email' => false,
            'emailConfirmation' => true
        ];

        if ($checked['success'] == 'true') {


            $snippet = $namespace->get(
                'EmailinBlacklist',
                "Leider ist das Registrieren mit Email Adressen wie %s nicht m&ouml;glich.",
                true
            );


            $errors = [
                'email' => sprintf($snippet, $checked['blacklistedemail']),
                'emailConfirmation' => false,
            ];


        }

        $this->Response()->setHeader('Content-type', 'application/json', true);
        $this->Response()->setBody(json_encode($errors));

    }
    /**
     * Check the Email
     * prueft die email in der blacklist
     * @public
     * @param Enlight_Event_EventArgs $args
     */
    public function CheckEmailBlacklist($user_email)
    {




        $dataSQL = "SELECT name FROM pix_emailblacklist";

        $emailblacklisted = Shopware()->Db()->fetchAll($dataSQL);


        if (is_array($emailblacklisted) and count($emailblacklisted) > 0) {

            $emailblacklisted_size = sizeof($emailblacklisted);


            for ($i = 0; $i < $emailblacklisted_size; $i++) {


                $emailblacklisted_current = trim($emailblacklisted[$i]['name']);
                if (stripos($user_email, $emailblacklisted_current) !== false) {


                    return array('success' => true, 'blacklistedemail' => $emailblacklisted_current);
                } else {

                }
            }

            return array('success' => false, 'blacklistedemail' => '');

        }
    }


    /**
     * @return array
     */
    private function getPostData()
    {
        $data = $this->request->getPost();


        return $data;
    }


}