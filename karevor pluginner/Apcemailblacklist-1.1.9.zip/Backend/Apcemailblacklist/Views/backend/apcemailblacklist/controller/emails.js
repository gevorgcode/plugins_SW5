//{namespace name="backend/apcemailblacklist/view/main"}
//{block name="backend/apcemailblacklist/controller/emails"}
Ext.define('Shopware.apps.Apcemailblacklist.controller.Emails', {
    /**
     * The parent class that this class extends.
     * @string
     */
    extend: 'Ext.app.Controller',

    refs: [
        { ref: 'detailForm', selector: 'apcemailblacklist-list-window apcemailblacklist-detail-panel' },
        { ref: 'EmailGrid', selector: 'apcemailblacklist-list-window apcemailblacklist-apcemailblacklist-list' }
    ],

    mainWindow: null,

    /**
     * A template method that is called when your application boots.
     * It is called before the Application's launch function is executed
     * so gives a hook point to run any code before your Viewport is created.
     *
     * @return Ext.window.Window
     */
    init: function () {
        var me = this;


        me.subApplication.listStore =  me.subApplication.getStore('List').load();
        console.log(me.subApplication.listStore);

        me.mainWindow = me.getView('blacklist.Window').create({
            listStore: me.subApplication.listStore
        });
        me.addControls();
        me.callParent(arguments);


    },

    /**
     * Helper function to register all component events
     */
    addControls: function () {
        var me = this;

        me.control({
            'apcemailblacklist-list-window apcemailblacklist-apcemailblacklist-list': {
                selectEmail: me.onSelectEmail,
                deleteEmail: me.onDeleteEmail,
                addEmail: me.onAddEmail
            },
            'apcemailblacklist-list-window apcemailblacklist-detail-panel': {
                nameChanged: me.onFormChange,
                commentChanged: me.onFormChange,
                saveEmail: me.onSaveEmail
            }
        });
    },

    /**
     * Event listener function of the Email grid.
     *
     */
    onSelectEmail: function (record) {
        var me = this;

        if (!(record instanceof Ext.data.Model)) {
            return;
        }
        me.loadEmail(record);
    },

    /**
     * Internal helper function which can be used to load a single
     * Email record into the detail panel.
     *
     */
    loadEmail: function (record) {


        var me = this,
            detailForm = me.getDetailForm();


        detailForm.loadRecord(record);
    },

    /**
     * Event listener function of the Email grid.
     * Event fired when the user clicks on the add button in the grid toolbar
     * to add a new Email record.
     */
    onAddEmail: function () {


        var me = this,
            EmailGrid = me.getEmailGrid();

        var Emailblacklist = Ext.create('Shopware.apps.Apcemailblacklist.model.Blackemail', {
            created: new Date,
            name: 'New EMail'
        });
        Emailblacklist.setDirty();
        EmailGrid.getStore().add(Emailblacklist);
        me.loadEmail(Emailblacklist);
    },

    /**
     * Event listener function of the Email grid.
     *
     */
    onDeleteEmail: function (record) {


        var me = this,
            EmailGrid = me.getEmailGrid(),
            message = '',
            name = '';

        if (!(record instanceof Ext.data.Model)) {
            return;
        }

        name = record.get('name');
        EmailGrid.getStore().remove(record);
        me.mainWindow.setLoading(true);
        record.destroy({
            success: function () {
                me.mainWindow.setLoading(false);
                message = '{s name="messages/save_success"}Email: [0] <br>Saved successfully{/s}';
                message = Ext.String.format(message, name);
                Shopware.Notification.createGrowlMessage('', message);
            },
            failure: function (result, operation) {
                me.mainWindow.setLoading(false);
                var rawData = result.getProxy().getReader().rawData;
                var message = '{s name="messages/save_failure"}Email: [0]<br><br>Save failure:{/s}  ' + rawData.error;
                message = Ext.String.format(message, name);
                Shopware.Notification.createGrowlMessage('', message);
            }
        });
    },


    /**
     * Event listener function of the detail panel.
     * Event fired when the user clicks on the save button
     * This function is used to save the passed record.
     *
     */
    onSaveEmail: function (record) {
        var me = this,
            message = '',
            EmailGrid = me.getEmailGrid(),
            detailForm = me.getDetailForm();
        if (!(record instanceof Ext.data.Model)) {
            return;
        }
        if (!detailForm.getForm().isValid()) {
            return;
        }
        detailForm.getForm().updateRecord(record);

        me.mainWindow.setLoading(true);
        record.save({
            success: function () {
                me.mainWindow.setLoading(false);

                EmailGrid.getSelectionModel().select(record);

                message = '{s name="messages/save_success"}Email: [0] <br>Saved successfully{/s}';
                message = Ext.String.format(message, record.get('name'));
                Shopware.Notification.createGrowlMessage('', message);
            },
            failure: function (result, operation) {
                me.mainWindow.setLoading(false);

                var rawData = result.getProxy().getReader().rawData;
                var message = '{s name="messages/save_failure"}Email: [0]{/s} <br><br>Save failure: ' + rawData.error;
                message = Ext.String.format(message, record.get('name'));

                Shopware.Notification.createGrowlMessage('', message);
            }
        });
    },

    /**
     * Event listener function of the detail panel.
     * Fired when the name or comment field changed and the blur event of the form field fired.
     * This function is used to set the dirty flag on the record to display the user that the record
     * has unsaved changes.
     *
     */
    onFormChange: function (newValue, field) {
        var me = this,
            detailForm = me.getDetailForm(),
            EmailGrid = me.getEmailGrid();
        if (!(detailForm.getRecord() instanceof Ext.data.Model)) {
            return;
        }
        if (newValue !== detailForm.getRecord().get(field)) {
            detailForm.getForm().updateRecord(detailForm.getRecord());
            detailForm.getRecord().setDirty();
            EmailGrid.reconfigure();
        }
    },


    /**
     * Helper function which returns the current selected Email grid record.
     *
     */
    getSelectedEmail: function () {
        var me = this,
            EmailGrid = me.getEmailGrid();
        if (!EmailGrid) {
            return null;
        }

        var selection = EmailGrid.getSelectionModel().getSelection();
        if (selection.length > 0) {
            return selection[0];
        } else {
            return null;
        }
    },


    /**
     * Creates and shows the list window of the Email module.
     */
    createMainWindow: function () {
        var me = this, window;

        window = me.getView('list.Window').create({
            listStore: Ext.create('Shopware.apps.Apcemailblacklist.store.List').load()
        }).show();

        return window;
    }
});
//{/block}
