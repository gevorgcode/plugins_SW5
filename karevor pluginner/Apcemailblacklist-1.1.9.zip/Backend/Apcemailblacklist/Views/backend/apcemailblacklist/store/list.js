 
//{block name="backend/apcemailblacklist/store/list"}
Ext.define('Shopware.apps.Apcemailblacklist.store.List', {

    /**
     * Define that this component is an extension of the Ext.data.Store
     */
    extend: 'Ext.data.Store',

    /**
     * Define how much rows loaded with one request
     */
    pageSize: 15,

    /**
     * Auto load the store after the component
     * is initialized
     */
    autoLoad: false,

    /**
     * Enable remote sorting
     */
    remoteSort: true,

    /**
     * Enable remote filtering
     */
    remoteFilter: true,

    /**
     * Define the used model for this store
     * @string
     */
    model : 'Shopware.apps.Apcemailblacklist.model.Blackemail',

    /**
     * Configure the data communication
     */
    proxy:{
        type:'ajax',

        /**
         * Configure the url mapping for the different
         * store operations based on
         * @object
         */
        url:'{url controller="Apcemailblacklist" action="getList"}',

        /**
         * Configure the data reader
         * @object
         */
        reader:{
            type:'json',
            root:'data',
            totalProperty:'total'
        }
    }
});
//{/block}