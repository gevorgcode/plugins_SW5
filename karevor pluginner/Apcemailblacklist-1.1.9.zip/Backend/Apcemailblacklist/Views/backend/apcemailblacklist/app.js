 

//{namespace name="backend/apcemailblacklist/view/main"}
//{block name="backend/apcemailblacklist/app"}
Ext.define('Shopware.apps.Apcemailblacklist', {

    /**
     * The name of the module. Used for internal purpose
     * @string
     */
    name:'Shopware.apps.Apcemailblacklist',

    /**
     * Extends from our special controller, which handles the sub-application behavior and the event bus
     * @string
     */
    extend:'Enlight.app.SubApplication',

    /**
     * Enable bulk loading
     * @boolean
     */
    bulkLoad:true,

    /**
     * Sets the loading path for the sub-application.
     *
     * @string
     */
    loadPath:'{url controller="Apcemailblacklist" action="load"}',

    /**
     * Array of views to require from AppName.view namespace.
     * @array
     */
    views:[
        'blacklist.Window',
        'blacklist.Emails',
        'blacklist.Detail'

    ],

    /**
     * Array of stores to require from AppName.store namespace.
     * @array
     */
    stores:[ 'List' ],

    /**
     * Array of models to require from AppName.model namespace.
     * @array
     */
    models: [ 'Blackemail' ],

    /**
     * Requires controllers for sub-application
     * @array
     */
    controllers: [ 'Emails' ],

    /**
     * Returns the main application window for this is expected
     * by the Enlight.app.SubApplication class.
     * The class sets a new event listener on the "destroy" event of
     * the main application window to perform the destroying of the
     * whole sub application when the user closes the main application window.
     *
     * This method will be called when all dependencies are solved and
     * all member controllers, models, views and stores are initialized.
     *
     */
    launch: function() {
        var me = this,
            mainController = me.getController('Emails');


        return mainController.mainWindow;
    }
});
//{/block}

