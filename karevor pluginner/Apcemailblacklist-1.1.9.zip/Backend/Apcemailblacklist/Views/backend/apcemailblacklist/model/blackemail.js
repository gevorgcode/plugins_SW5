//{block name="backend/apcemailblacklist/model/blackemail"}
Ext.define('Shopware.apps.Apcemailblacklist.model.Blackemail', {
    /**
     * Extends the standard Ext Model
     * @string
     */
    extend: 'Ext.data.Model',

    /**
     * The fields used for this model
     * @array
     */
    fields: [
        { name: 'id', type: 'int', useNull: true },
        { name: 'name', type: 'string' },
        { name: 'comment', type: 'string' },
        { name: 'position', type: 'int', defaultValue: 1 },
        { name: 'created', type: 'date' }
    ],

    

    /**
     * Configure the data communication
     * @object
     */
    proxy: {
        /**
         * Set proxy type to ajax
         * @string
         */
        type:'ajax',

        /**
         * Configure the url mapping for the different
         * store operations based on
         * @object
         */
        api: {
            create: '{url controller="Apcemailblacklist" action="createEmail"}',
            update: '{url controller="Apcemailblacklist" action="updateEmail"}',
            destroy: '{url controller="Apcemailblacklist" action="deleteEmail"}'
        },

        /**
         * Configure the data reader
         * @object
         */
        reader:{
            type:'json',
            root:'data',
            totalProperty:'total'
        }
    }
});
//{/block}
