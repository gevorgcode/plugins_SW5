 

//{namespace name="backend/apcemailblacklist/view/main"}
//{block name="backend/apcemailblacklist/view/blacklist/window"}
Ext.define('Shopware.apps.Apcemailblacklist.view.blacklist.Window', {
    /**
     * Define that the order main window is an extension of the enlight application window
     * @string
     */
    extend:'Enlight.app.Window',
    /**
     * Set base css class prefix and module individual css class for css styling
     * @string
     */
    cls:Ext.baseCSSPrefix + 'apcemailblacklist-list-window',
    /**
     * List of short aliases for class names. Most useful for defining xtypes for widgets.
     * @string
     */
    alias:'widget.apcemailblacklist-list-window',
    /**
     * Set no border for the window
     * @boolean
     */
    border:false,
    /**
     * True to automatically show the component upon creation.
     * @boolean
     */
    autoShow:true,
    /**
     * True to display the 'maximize' tool button and allow the user to maximize the window, false to hide the button and disallow maximizing the window.
     * @boolean
     */
    maximizable:true,
    /**
     * True to display the 'minimize' tool button and allow the user to minimize the window, false to hide the button and disallow minimizing the window.
     * @boolean
     */
    minimizable:true,

    layout: {
        type: 'hbox',
        align: 'stretch'
    },

    width: 900,
    height: 600,

    /**
     * The initComponent template method is an important initialization step for a Component.
     * It is intended to be implemented by each subclass of Ext.Component to provide any needed constructor logic.
     * The initComponent method of the class being created is called first,
     * with each initComponent method up the hierarchy to Ext.Component being called thereafter.
     * This makes it easy to implement and, if needed, override the constructor logic of the Component at any step in the hierarchy.
     * The initComponent method must contain a call to callParent in order to ensure that the parent class' initComponent method is also called.
     *
     * @return void
     */
    initComponent:function () {
        var me = this;
        me.items = [
            me.createEmailGrid(),
            me.createDetailPanel()
        ];
        me.title = '{s name="window/title"}EMail overview{/s}';

        me.callParent(arguments);
    },



    /**
     * Creates the favorite grid which displays all defined favorites.
     *
     */
    createEmailGrid: function() {
        var me = this;
 
        return Ext.create('Shopware.apps.Apcemailblacklist.view.blacklist.Emails', {
            store: me.listStore,
            flex: 1
        });
    },

    /**
     * Creates the detail panel which displayed on the right side of the window.
     * The detail panel displays the favorite articles and configuration fields.
     */
    createDetailPanel: function() {
        return Ext.create('Shopware.apps.Apcemailblacklist.view.blacklist.Detail', {
            title: '{s name="window/detail_panel_header"}Email details{/s}',
            width: 450
        });
    }
});
//{/block}