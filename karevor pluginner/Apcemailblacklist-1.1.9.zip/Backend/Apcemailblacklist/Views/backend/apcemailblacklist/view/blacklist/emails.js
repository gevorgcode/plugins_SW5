 

//{namespace name="backend/apcemailblacklist/view/main"}
//{block name="backend/apcemailblacklist/view/blacklist/emails"}
Ext.define('Shopware.apps.Apcemailblacklist.view.blacklist.Emails', {

    extend: 'Ext.grid.Panel',

    border: false, autoScroll: true,
    /**
     * Set base css class prefix and module individual css class for css styling
     * @string
     */
    cls: Ext.baseCSSPrefix + 'apcemailblacklist-apcemailblacklist-list',

    /**
     * List of short aliases for class names. Most useful for defining xtypes for widgets.
     * @string
     */
    alias: 'widget.apcemailblacklist-apcemailblacklist-list',

    /**
     * Called when the component will be initialed.
     */
    initComponent: function () {
        var me = this;
        me.registerEvents();
        me.selModel = me.createSelectionModel();
        me.columns = me.createColumns();
        me.tbar = me.createToolbar();


        me.bbar = me.createToolbbar();
        me.callParent(arguments);


    },

    /**
     * Creates the grid toolbar for the favorite grid
     * @return Ext.toolbar.Toolbar
     */
    createToolbar: function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            dock: 'top',
            items: [
                me.createAddButton(),

            ]
        });
    },

    /**
     * Creates the grid toolbar for the favorite grid
     * @return Ext.toolbar.Toolbar
     */
    createToolbbar: function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            dock: 'bottom',
            items: [
                me.getPagingBar()
            ]
        });
    },


    /**
     * Creates the add button of the grid toolbar.
     *
     * @return Ext.button.Button
     */
    createAddButton: function () {
        var me = this;

        return Ext.create('Ext.button.Button', {
            text: '{s name="apcemailblacklist/add_email"}Add Email{/s}',
            cls: 'secondary small',
            iconCls: 'sprite-plus-circle-frame',
            handler: function () {

                me.fireEvent('addEmail');
            }
        });
    },

    /**
     * Registers additional component events.
     */
    registerEvents: function () {
        this.addEvents('deleteEmail', 'selectEmail', 'addEmail');
    },

    /**
     * Creates the grid selection model.
     */
    createSelectionModel: function () {
        var me = this;

        return Ext.create('Ext.selection.RowModel', {
            listeners: {
                selectionchange: function (view, selected) {

                    me.fireEvent('selectEmail', selected[0]);
                }
            }
        });
    },

    /**
     * Creates the grid columns.
     */
    createColumns: function () {
        var me = this;

        return [
            me.createNameColumn(),
            me.createActionColumn()
        ];
    },

    /**
     * Creates the name column for the article grid
     * @return Object
     */
    createNameColumn: function () {
        var me = this;

        return {
            header: '{s name="apcemailblacklist/name_column"}Email name{/s}',
            flex: 2,
            dataIndex: 'name',
            renderer: me.nameColumnRenderer
        }
    },

    /**
     * Creates the action columns for the article grid.
     * @return Ext.grid.column.Action
     */
    createActionColumn: function () {
        var me = this;

        var items = me.getActionColumnItems();

        return Ext.create('Ext.grid.column.Action', {
            items: items,
            width: items.length * 30
        });
    },

    /**
     * Creates the different action column items for the action
     * column of the favorites grid.
     * @return Array
     */
    getActionColumnItems: function () {
        var me = this,
            items = [];

        items.push(me.createDeleteActionItem());
        return items;
    },

    /**
     * Creates delete action column item for the favorites grid.
     * The action column items deletes the selected record
     * selected article.
     * @return Object
     */
    createDeleteActionItem: function () {
        var me = this;

        return {
            iconCls: 'sprite-minus-circle-frame',
            cls: 'open-article',
            tooltip: '{s name="apcemailblacklist/delete_column"}Delete Email{/s}',
            handler: function (grid, rowIndex, colIndex, metaData, event, record) {


                me.fireEvent('deleteEmail', record);
            }
        };
    },
    /**
     * Creates the paging toolbar for the blog grid to allow
     * and store paging. The paging toolbar uses the same store as the Grid
     *
     * @return Ext.toolbar.Paging The paging toolbar for the customer grid
     */
    getPagingBar: function () {
        var me = this;
        return Ext.create('Ext.toolbar.Paging', {
            store: me.store,
            dock: 'bottom',
            displayInfo: true
        });

    },

    /**
     * Renderer function for the article number column.
     * @return String
     */
    nameColumnRenderer: function (value, metaData, record) {
        var comment = '{s name="apcemailblacklist/no_comment"}no comment{/s}';

        if (!(record instanceof Ext.data.Model)) {
            return value;
        }

        if (record.get('comment')) {
            comment = record.get('comment');
        }
        var commentEl = '<span style="color: #7d7d7d; font-size: 10px;">' + comment + '</span>';
        var nameEl = '<span style="font-weight: 700;">' + value + '</span>';

        return nameEl + ' - ' + commentEl;
    }

});

//{/block}
