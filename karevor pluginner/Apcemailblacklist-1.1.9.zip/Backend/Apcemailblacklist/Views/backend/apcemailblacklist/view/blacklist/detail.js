/**
 * Shopware 4.0
 * Copyright © 2012 shopware AG
 *
 * According to our dual licensing model, this program can be used either
 * under the terms of the GNU Affero General Public License, version 3,
 * or under a proprietary license.
 *
 * The texts of the GNU Affero General Public License with an additional
 * permission and of our proprietary license can be found at and
 * in the LICENSE file you have received along with this program.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * "Shopware" is a registered trademark of shopware AG.
 * The licensing of the program under the AGPLv3 does not imply a
 * trademark license. Therefore any rights, title and interest in
 * our trademarks remain entirely with us.
 *
 * @category   Shopware
 * @copyright  Copyright (c) 2012, shopware AG (http://www.shopware.de)
 * @author shopware AG
 */

//{namespace name="backend/apcemailblacklist/view/main"}
//{block name="backend/apcemailblacklist/view/blacklist/detail"}
Ext.define('Shopware.apps.Apcemailblacklist.view.blacklist.Detail', {

    extend: 'Ext.form.Panel',

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    border: false,
    bodyPadding: 10,

    /**
     * List of short aliases for class names. Most useful for defining xtypes for widgets.
     * @string
     */
    alias: 'widget.apcemailblacklist-detail-panel',

    /**
     * Called when the component will be initialed.
     */
    initComponent: function () {
        var me = this;
        me.items = me.createItems();
        me.callParent(arguments);
    },

    /**
     * Returns the created form elements.
     * @return Array
     */
    createItems: function () {
        var me = this;

        return [
            me.createFormFields(),
            me.createSaveButton()
        ];
    },

    /**
     * Creates the form save button, which can be used to save the changes of the current selected favorite record.
     * @return Ext.button.Button
     */
    createSaveButton: function () {
        var me = this;

        return Ext.create('Ext.button.Button', {
            cls: 'primary',
            text: '{s name="detail/save_button"}Save{/s}',
            margin: '10 0 0',
            handler: function () {
                me.fireEvent('saveEmail', me.getRecord());
            }
        });
    },

    /**
     * Creates an form field set with all required configuration fields.
     *
     * @return Ext.form.FieldSet
     */
    createFormFields: function () {
        var me = this;

        return Ext.create('Ext.form.FieldSet', {
            flex: 1,
            collapsible: false,
            title: '{s name="details/field_set_title"}Email data{/s}',
            autoScroll: true,
            layout: 'anchor',
            items: [
                me.createNameField(),
                me.createCommentField(),
                me.createDateField()
            ]
        });
    },

    /**
     * Creates the form field to configure the favorite name
     * @return Ext.form.field.Text
     */
    createNameField: function () {
        var me = this;

        return Ext.create('Ext.form.field.Text', {
            name: 'name',
            anchor: '100%',
            allowBlank: false,
            fieldLabel: '{s name="detail/name_field"}Name{/s}',
            listeners: {
                blur: function () {
                    me.fireEvent('nameChanged', this.getValue(), 'name');
                }
            }
        });
    },

    /**
     * Creates the display field for the creation date of the favorite record.
     * @return Ext.form.field.Display
     */
    createDateField: function () {
        var me = this;

        return Ext.create('Ext.form.field.Display', {
            name: 'created',
            anchor: '100%',
            fieldLabel: '{s name="detail/create_field"}Created at{/s}',
            renderer: function (value) {
                if (me.getRecord()) {
                    var createDate = me.getRecord().get('created');
                    return '<span style="padding-top: 3px; display:block;">' + Ext.util.Format.date(createDate) + '</span>';

                } else {
                    return value;
                }
            }
        });
    },

    /**
     * Creates the form field to configure the favorite comment.
     * @return Ext.form.field.TextArea
     */
    createCommentField: function () {
        var me = this;

        return Ext.create('Ext.form.field.TextArea', {
            name: 'comment',
            anchor: '100%',
            grow: true,
            growMax: 100,
            fieldLabel: '{s name="detail/comment_field"}Comment{/s}',
            listeners: {
                blur: function () {
                    me.fireEvent('commentChanged', this.getValue(), 'comment');
                }
            }
        });
    }
});

//{/block}
