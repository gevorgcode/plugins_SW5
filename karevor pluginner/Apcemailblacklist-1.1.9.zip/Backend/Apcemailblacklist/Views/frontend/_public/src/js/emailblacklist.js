(function ($) {
    "use strict";
    $.subscribe('plugin/swRegister/onValidateBefore', function (me, $input) {


        if (ebValidate == true) {

            $('#ajax_validate_email--after').remove();
            $('.register--submit').prop("disabled", false);
            $('.register--submit').removeClass("is--disabled");

        }

    });

})(jQuery);

(function ($) {
    "use strict";
    $.subscribe('plugin/swRegister/onValidateSuccess', function (me, $input) {

        if (ebValidate == true) {
            var me = this,
                data = 'action=ajax_validate_email&' + $('.register--form').serialize(),
                URL = ebcontroller + '/ajax_validate_email/';

            if (!URL) {
                return;
            }

            $.ajax({
                'data': data,
                'type': 'post',
                'dataType': 'json',
                'url': URL,
                'success': function (result) {

                    $('#ajax_validate_email--after').remove();


                    if (result.emailConfirmation == false) {

                        $('.register--submit').prop("disabled", true);
                        $('.register--submit').addClass("is--disabled");
                        $('<div>', {
                            'html': '<p>' + result.email + '</p>',
                            'id': 'ajax_validate_email--after',
                            'class': "register--error-msg"
                        }).insertAfter($('#register_personal_email'));

                    } else {
                        $('#ajax_validate_email--after').remove();
                        $('.register--submit').prop("disabled", false);
                        $('.register--submit').removeClass("is--disabled");
                    }


                }
            });
        }
    });


})(jQuery);

/*

;(function($, window) {
    'use strict';



    $.plugin('blackListForm', {


        init: function () {
            var me = this;

            me.applyDataAttributes();
            console.log('init');
            console.log(me);
            me.registerEvents();
        },

        registerEvents: function () {
            var me = this;
            console.log('init2');
            console.log(me);
            me._on(me.$el, 'click', $.proxy(me.onSubmitFormButton, me));
        },


        onSubmitFormButton: function (event) {


            var me = this;
            var $form = me.$el.closest('form#support');



            var formerror = false;

            if (ebFormValidate == true) {
                var me = this,
                    data = 'action=ajax_validate_form_email&' + $('form#support').serialize(),
                    URL = ebcontroller + '/ajax_validate_form_email/';

                if (!URL) {
                    return;
                }

                $.ajax({
                    'data': data,
                    'type': 'post',
                    'dataType': 'json',
                    'url': URL,
                    'success': function (result) {

                        $('#ajax_validate_email--after').remove();


                        if (result.emailConfirmation == false) {

                            $('form#support btn').prop("disabled", true);
                            $('form#support btn').addClass("is--disabled");

                            var EmailError = '<div id="ajax_validate_email--after" class="alert is--error is--rounded">\n' +
                                '                                <div class="alert--icon"><i class="icon--element icon--cross"></i></div>\n' +
                                '                                <div class="alert--content">' + result.email + '</div>\n' +
                                '                            </div>';
                            $('.is--ctl-forms .forms--content .error').append(EmailError);

                            var formerror = true;
                            return false;

                        } else {
                            $('#ajax_validate_email--after').remove();
                            $('form#support btn').prop("disabled", false);
                            $('form#support btn').removeClass("is--disabled");

                            var formerror = false;
                        }


                    }
                });



                if (formerror == true) {

                    return false;
                }

            }


        },


    });

    StateManager.addPlugin('form#support button[name="Submit"]', 'blackListForm');

})(jQuery, window);
*/



