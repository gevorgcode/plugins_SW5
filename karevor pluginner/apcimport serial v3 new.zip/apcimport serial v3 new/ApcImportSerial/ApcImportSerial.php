<?php

namespace ApcImportSerial;

use Shopware\Components\Plugin;
use Doctrine\ORM\Tools\SchemaTool;
use ApcImportSerial\Models\SerialAttributeModel;

class ApcImportSerial extends Plugin
{
     /**
     * @param Plugin\Context\InstallContext $context
     */
    public function install(Plugin\Context\InstallContext $context)
    {
        $service = $this->container->get('shopware_attribute.crud_service');
        $service->update('s_articles_esd_attributes', 'esd_serial_limit', 'integer');
        $service->update('s_articles_esd_attributes', 'esd_serial_limit_active', 'boolean');
                
        $metaDataCache = Shopware()->Models()->getConfiguration()->getMetadataCacheImpl();
        $metaDataCache->deleteAll();
        Shopware()->Models()->generateAttributeModels(['s_articles_esd_attributes']);

        //
        $em = $this->container->get('models');
        $tool = new SchemaTool($em);
        $classes = [$em->getClassMetadata(SerialAttributeModel::class)];
        $tool->createSchema($classes);
    }
    
}
