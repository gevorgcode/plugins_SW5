<?php

namespace ApcImportSerial\Components;

class Constants
{
    const IMS_PER_PAGE = 20;
}
?>


