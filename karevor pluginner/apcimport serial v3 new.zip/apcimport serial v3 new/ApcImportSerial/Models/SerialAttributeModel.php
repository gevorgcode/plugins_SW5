<?php
namespace ApcImportSerial\Models;

use Shopware\Components\Model\ModelEntity;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity()
 * @ORM\Table(name="s_articles_esd_serials_attributes", options={"collate"="utf8_unicode_ci"})
 */
class SerialAttributeModel extends ModelEntity
{
    /**
    * @var int
    *
    * @ORM\Column(name="id", type="integer", nullable=false)
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="IDENTITY")
    */
    private $id;   
    
    /**
    * @var int
    * @ORM\Column(name="serialID", type="integer", nullable=true)
    */    
    private $serialId;          
       
    /**
    * @var string
    * @ORM\Column(name="dealer", type="string", nullable=true)
    */
    private $dealer;

    /**
    * @var datetime
    * @ORM\Column(name="import_date", type="datetime", nullable=true)
    */
    private $importDate; 
}
