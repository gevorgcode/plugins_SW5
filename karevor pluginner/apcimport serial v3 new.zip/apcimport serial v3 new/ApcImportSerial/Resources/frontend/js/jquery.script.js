;(function ($,window,document) {    
 
    var imscollapse = {

        clickButton: ".ims--collapse-btn",
        data: "",
        collapseSelector: "",
        iconSelector: "",
 
         init: function(){
             var me = this;
             me.getSelectors();      
                          
         },

        getSelectors: function(){
            var me = this;
            $(me.clickButton).click(function(){                
               me.data = '.' + $(this).data('selector');
               me.collapseSelector = me.data + ' .ims--cont-div';
               me.iconSelector = me.data + ' .icon--toggle';
               me.collapse(me.collapseSelector, me.iconSelector, me.data);                
           });
        }, 
 
         collapse: function(collapseSelector, iconSelector, data){
             var me = this;
            $(collapseSelector).slideToggle(500);
            setTimeout(function(){ 
                $(iconSelector).toggleClass('icon--arrow-down');
                $(iconSelector).toggleClass('icon--arrow-up');
            }, 300);
         },          
     };
 
     $(document).ready(function() {
         imscollapse.init();
     });
    
})($,window,document);    
