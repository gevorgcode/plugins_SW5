<?php

use DateTime;
use ApcImportSerial\Components\Constants;

/**
 * Class Shopware_Controllers_Frontend_Importserialcustom
 */
class Shopware_Controllers_Frontend_Importserialcustom extends Enlight_Controller_Action{

    protected $session; 
    protected $db;
    protected $limit;

    /**
     * Init controller method
     */
    public function init(){          
        $this->session = Shopware()->Session();        
        $this->db = Shopware()->Db();
        $this->limit = $limit = Constants::IMS_PER_PAGE;

        $this->View()->assign('SeoMetaRobots', 'noindex,nofollow');        
    }
        
    public function indexAction(){
        if (!$this->Request()->getCookie('SaL') || ($this->session->offsetGet('SalT') < time())){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }

        if ($this->Request()->getParam('art_onumber') && $this->Request()->getParam('addcount')){
            $this->View()->assign('art_onumber', $this->Request()->getParam('art_onumber'));  
            $this->View()->assign('addcount', $this->Request()->getParam('addcount'));  
        }        
    } 
    
    public function serialloginAction(){        
    //        tpl
    }
    
    public function logoutAction(){        
        $this->Response()->setCookie( 'SaL', true, time()-3600, '/', null, true, true );
        $this->session->offsetSet('SalT', time()-1);
        $this->redirect([
            'action' => 'seriallogin',
        ]);
    }
    
    public function loginAction(){        
        if (!$this->Request()->isPost()){
            return;
        }

        $params = $this->clearParams($this->Request()->getParams());
        
        $user = $this->db->fetchRow(
            'SELECT *
            FROM s_core_auth             
            WHERE s_core_auth.username = :username
            AND s_core_auth.roleID = 1',            
            ['username' => $params['login']]
        );
        
        if (!$user){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
        }        
             
        if (!password_verify($params['password'], $user['password'])){
            return;
        }
       
        $this->Response()->setCookie( 'SaL', true, time()+3600, '/', null, true, true );
        $this->session->offsetSet('SalT', time()+3600);
        $this->redirect([
            'action' => 'index',
        ]);               
    }
    
    public function articleAction(){
        if (!$this->Request()->isPost()){
            return;
        }
        
        if (!$this->Request()->getCookie('SaL') || ($this->session->offsetGet('SalT') < time())){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }

        $params = $this->clearParams($this->Request()->getParams());       

        $article = $this->getArticle($params['art_onumber']);        

        $error['type'] = null;
        if (!$article){
            $error['type'] = 'noMatchOrdernumber';
        }elseif (!$article['esdId']){
            $error['type'] = 'noEsdArticle';
        }elseif ($article['serials'] != 1){
            $error['type'] = 'serialsDisabled';
        }
        if ($error['type']){
            $error['ordernumber'] = $params['art_onumber'];
            $this->View()->assign('error', $error);
            return;
        }    

        $article['serialsCount'] = $this->getSerialsCount($article['esdId']);
        $article['esdAttributes'] = $this->db->fetchRow('SELECT * FROM s_articles_esd_attributes WHERE s_articles_esd_attributes.esdID = :esdID', ['esdID' => $article['esdId']]);         
        
        $this->View()->assign('article', $article);        
    }
    
    public function createserialAction(){
        if (!$this->Request()->isPost()){
            return;
        }
        
        if (!$this->Request()->getCookie('SaL') || ($this->session->offsetGet('SalT') < time())){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }
        
        $params = $this->clearParams($this->Request()->getParams());          

        $article = $this->db->fetchRow(
            'SELECT `s_articles_details`.`id` as detailId,            
            `s_articles_esd`.`id` as esdId                   
             FROM `s_articles_details`
             LEFT JOIN `s_articles_esd`
             ON `s_articles_details`.`id` = `s_articles_esd`.`articledetailsID`             
             WHERE `s_articles_details`.`ordernumber` = :ordernumber',
            ['ordernumber' => $params['ordernumber']]
        ); 
        
        if (!$article['esdId'] || $params['esdId'] != $article['esdId'] || empty($params['serials'])){            
            return;
        }      
        
        $serialsArr = explode("\n", $params['serials']);
        $dateTime = new DateTime();
        $date = $dateTime->format('Y-m-d H:i:s');

        $i = 0;
        foreach ($serialsArr as $serial){            
            if (strlen($serial) > 3){
                $i++;                
                $this->db->insert('s_articles_esd_serials', [
                    'serialnumber' => $serial,
                    'esdID' => $article['esdId'],
                ]);   

                $this->db->insert('s_articles_esd_serials_attributes', [
                    'serialID' => $this->db->lastInsertId(),
                    'dealer' => $params['dealer'],
                    'import_date' => $date,
                ]);                  
            }
        }
        
        $this->redirect([
            'action' => 'index',
            'art_onumber' => $params['ordernumber'],
            'addcount' => $i,
        ]);                
    }
    
    public function setlimitAction(){       

        if (!$this->Request()->isPost()){
            return;
        }        

        if (!$this->Request()->getCookie('SaL') || ($this->session->offsetGet('SalT') < time())){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }

        $params = $this->clearParams($this->Request()->getParams());
        
        if (!$params['esdId']){
            return;
        }

        $limit = null;
        $active = 0;

        if($params['limit_active']){
            $active = 1;
        }        
        
        if($params['limit']){
            $limit = $params['limit'];
        }
        
        $esdAttrId = $this->db->fetchOne(
            'SELECT id
            FROM s_articles_esd_attributes
            WHERE s_articles_esd_attributes.esdID = :esdID',             
            ['esdID' => $params['esdId']]
        );  

        if ($esdAttrId){
            $this->db->query(
                'UPDATE s_articles_esd_attributes
                SET s_articles_esd_attributes.esd_serial_limit = :limit,
                s_articles_esd_attributes.esd_serial_limit_active = :active
                WHERE s_articles_esd_attributes.esdID = :esdID',
                ['limit' => $limit, 'active' => $active, 'esdID' => $params['esdId']]           
            ); 
        }else{
            $this->db->query(
                'INSERT INTO `s_articles_esd_attributes` (`esdID`, `esd_serial_limit`, `esd_serial_limit_active`) VALUES (?,?,?);',
                [$params['esdId'], $limit, $active]           
            ); 
        } 
        
        $this->forward('article', null, null, ['art_onumber' => $params['art_onumber']]);
    }  
    
    public function setesdattrAction(){        
        
        if (!$this->Request()->isPost()){
            return;
        }
        
        if (!$this->Request()->getCookie('SaL') || ($this->session->offsetGet('SalT') < time())){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }
        
        $params = $this->clearParams($this->Request()->getParams());
        
        if (!$params['esdId']){
            return;
        }

        $active = 0;
        if($params['additional_download_active']){
            $active = 1;
        }     
        
        $this->db->query(
            'UPDATE s_articles_esd_attributes
            SET s_articles_esd_attributes.text_1 = :text_1,
            s_articles_esd_attributes.text_2 = :text_2,
            s_articles_esd_attributes.text_3 = :text_3,
            s_articles_esd_attributes.text_4 = :text_4,
            s_articles_esd_attributes.file_1 = :file_1,
            s_articles_esd_attributes.file_2 = :file_2,
            s_articles_esd_attributes.file_3 = :file_3,
            s_articles_esd_attributes.file_4 = :file_4,
            s_articles_esd_attributes.additional_download_active = :active
            WHERE s_articles_esd_attributes.esdID = :esdID',
            [
                'text_1' => $params['text_1'], 
                'text_2' => $params['text_2'], 
                'text_3' => $params['text_3'], 
                'text_4' => $params['text_4'], 
                'file_1' => $params['file_1'], 
                'file_2' => $params['file_2'], 
                'file_3' => $params['file_3'], 
                'file_4' => $params['file_4'], 
                'active' => $active, 
                'esdID' => $params['esdId']
            ]           
        ); 
        if (count($params) > 17){            
            $this->db->query(
                'UPDATE s_articles_esd_attributes
                SET s_articles_esd_attributes.text_5 = :text_5,
                s_articles_esd_attributes.text_6 = :text_6,
                s_articles_esd_attributes.text_7 = :text_7,
                s_articles_esd_attributes.text_8 = :text_8,
                s_articles_esd_attributes.file_5 = :file_5,
                s_articles_esd_attributes.file_6 = :file_6,
                s_articles_esd_attributes.file_7 = :file_7,
                s_articles_esd_attributes.file_8 = :file_8                
                WHERE s_articles_esd_attributes.esdID = :esdID',
                [
                    'text_5' => $params['text_5'], 
                    'text_6' => $params['text_6'], 
                    'text_7' => $params['text_7'], 
                    'text_8' => $params['text_8'], 
                    'file_5' => $params['file_5'], 
                    'file_6' => $params['file_6'], 
                    'file_7' => $params['file_7'], 
                    'file_8' => $params['file_8'], 
                    'esdID' => $params['esdId']
                ]           
            ); 
        }
        $this->forward('article', null, null, ['art_onumber' => $params['art_onumber']]);
    }

    public function freeAction(){
        
        if (!$this->Request()->isPost()){
            return;
        }

        if (!$this->Request()->getCookie('SaL') || ($this->session->offsetGet('SalT') < time())){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }

        $params = $this->clearParams($this->Request()->getParams());
        
        $article = $this->getArticle($params['ordernumber']);

        if (!$article['esdId'] || $article['esdId'] != $params['esdId']){
            return;
        }   
        
        $article['count'] = $this->getFreeCount($article['esdId']);

        if ($article['count'] < 1){
            $this->forward('article', null, null, ['art_onumber' => $params['ordernumber']]);
            return;
        }

        $pagination = $this->getPagination($article['count'], $params['page']);        
        
        $article['freeSerials'] = $this->getFreeSerials($article['esdId'], $pagination['offset']);     
        $article['pagination'] = $pagination;        
        
        if (count($article['freeSerials']) < 1){
            return;
        }
       
        $this->View()->assign('article', $article);
    }

    public function usedAction(){
        
        if (!$this->Request()->isPost()){
            return;
        }

        if (!$this->Request()->getCookie('SaL') || ($this->session->offsetGet('SalT') < time())){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }

        $params = $this->clearParams($this->Request()->getParams());
        $article = $this->getArticle($params['ordernumber']);

        if (!$article['esdId'] || $article['esdId'] != $params['esdId']){
            return;
        }       
        
        $article['count'] = $this->getUsedCount($article['esdId']);
        $pagination = $this->getPagination($article['count'], $params['page']);        
        $article['usedSerials'] = $this->getUsedSerials($article['esdId'], $pagination['offset']);      
        $article['pagination'] = $pagination;        

        if (count($article['usedSerials']) < 1){
            return;
        }
        
        foreach ($article['usedSerials'] as &$usedSerial){
            $usedSerial['orderOrdernumber'] =  $this->db->fetchOne(
                'SELECT ordernumber                   
                 FROM s_order       
                 WHERE s_order.id = :orderId',
                ['orderId' => $usedSerial['orderId']]
            ); 

            $usedSerial['userEmail'] =  $this->db->fetchOne(
                'SELECT email                   
                 FROM s_user       
                 WHERE s_user.id = :userId',
                ['userId' => $usedSerial['userId']]
            ); 
        }          
        
        $this->View()->assign('article', $article);
    }

    public function searchAction(){        

        if (!$this->Request()->isPost()){
            return;
        }
        
        if (!$this->Request()->getCookie('SaL') || ($this->session->offsetGet('SalT') < time())){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }

        $params = $this->clearParams($this->Request()->getParams());    
        $result = $this->searchResultKey($params['term']);
        
        $this->View()->assign('imsSearchResult', $result);
    }

    public function dealerAction(){
        if (!$this->Request()->isPost()){
            return;
        }
        
        if (!$this->Request()->getCookie('SaL') || ($this->session->offsetGet('SalT') < time())){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }

        $params = $this->clearParams($this->Request()->getParams());   

        $articleCounts = $this->searchResultDealerCount($params['term']);

        $this->View()->assign('articleCounts', $articleCounts);
    }

    public function dealerfreeAction(){
        if (!$this->Request()->isPost()){
            return;
        }
        
        if (!$this->Request()->getCookie('SaL') || ($this->session->offsetGet('SalT') < time())){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }

        $params = $this->clearParams($this->Request()->getParams());  

        $article['count'] = $this->searchResultDealerCount($params['term'])['free'];
        
        if ($article['count'] < 1){
            $this->forward('dealer', null, null, ['term' => $params['term']]);
            return;
        }
        
        $pagination = $this->getPagination($article['count'], $params['page']);        
        
        $article['freeSerials'] = $this->getFreeSerialsDealer($params['term'], $pagination['offset']);     
        $article['pagination'] = $pagination;        
        $article['term'] = $params['term'];        
        
        if (count($article['freeSerials']) < 1){
            return;
        }
        
        $this->View()->assign('article', $article);
    }

    public function dealerusedAction(){
        
        if (!$this->Request()->isPost()){
            return;
        }

        if (!$this->Request()->getCookie('SaL') || ($this->session->offsetGet('SalT') < time())){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }

        $params = $this->clearParams($this->Request()->getParams());
        $article['count'] = $this->searchResultDealerCount($params['term'])['used'];

        if ($article['count'] < 1){
            $this->forward('dealer', null, null, ['term' => $params['term']]);
            return;
        }
        $pagination = $this->getPagination($article['count'], $params['page']); 
        $article['usedSerials'] = $this->getUsedSerialsDealer($params['term'], $pagination['offset']);

        $article['pagination'] = $pagination;        
        $article['term'] = $params['term'];        
        
        if (count($article['usedSerials']) < 1){
            return;
        }        
       
        $this->View()->assign('article', $article);        
    }

    public function deleteserialAction(){        
        if (!$this->Request()->isPost()){
            return;
        }

        if (!$this->Request()->getCookie('SaL') || ($this->session->offsetGet('SalT') < time())){
            $this->redirect([
                'action' => 'seriallogin',
            ]);
            return;
        }

        $params = $this->clearParams($this->Request()->getParams());
        
        $function = $params['function_name']; //deleteone(), deleteallonum(),deletealldealer(),deleteonedealer()
        $this->$function($params);        
    }

    //!!!don't delete this function, caled by variable name - $this->$function($params)
    private function deleteone($params){       
        
        $this->db->query(
            'DELETE 
            FROM s_articles_esd_serials
            WHERE s_articles_esd_serials.id = :serialId',
            ['serialId' => $params['serialId']]            
        ); 
        if ($params['serialAttrId']){
            $this->db->query(
                'DELETE 
                FROM s_articles_esd_serials_attributes
                WHERE s_articles_esd_serials_attributes.id = :serialAttrId',
                ['serialAttrId' => $params['serialAttrId']]            
            ); 
        }
        
        $this->forward($params['sTarget'], null, null, $params);
    }

    //!!!don't delete this function, caled by variable name - $this->$function($params)
    private function deleteonedealer($params){       
        
        $this->db->query(
            'DELETE 
            FROM s_articles_esd_serials
            WHERE s_articles_esd_serials.id = :serialId',
            ['serialId' => $params['serialId']]            
        ); 
        if ($params['serialAttrId']){
            $this->db->query(
                'DELETE 
                FROM s_articles_esd_serials_attributes
                WHERE s_articles_esd_serials_attributes.id = :serialAttrId',
                ['serialAttrId' => $params['serialAttrId']]            
            ); 
        }
        
        $this->forward($params['sTarget'], null, null, $params);
    }

    //!!!don't delete this function, caled by variable name - $this->$function($params)
    //need to optimize speed
    private function deleteallonum($params){        
       
        $this->db->query(
            'DELETE 
            FROM `s_articles_esd_serials`
            WHERE `s_articles_esd_serials`.`esdID` = :esdID
            AND NOT `s_articles_esd_serials`.`id` IN (SELECT serialID FROM s_order_esd)',
            ['esdID' => $params['esdId']]
        );     

        $this->db->query(
            "DELETE 
            FROM `s_articles_esd_serials_attributes`                          
            WHERE NOT `s_articles_esd_serials_attributes`.`serialID` IN (SELECT id FROM s_articles_esd_serials)"
        );         

        $this->forward($params['sTarget'], null, null, $params);
    }

    //!!!don't delete this function, caled by variable name - $this->$function($params)
    //speed optimized, working faster
    private function deletealldealer($params){       
        $term = $params['term'];

        $result = $this->db->fetchAll(
            "SELECT `s_articles_esd_serials_attributes`.`id` as `serialAttrId`,
            `s_articles_esd_serials_attributes`.`serialID` as `serialId`                      
            FROM `s_articles_esd_serials_attributes`     
            LEFT JOIN `s_articles_esd_serials`
            ON `s_articles_esd_serials_attributes`.`serialID` = `s_articles_esd_serials`.`id`                
            WHERE `s_articles_esd_serials_attributes`.`dealer` LIKE '%$term%'
            AND NOT `s_articles_esd_serials_attributes`.`serialID` IN (SELECT serialID FROM s_order_esd)"
        );

        foreach ($result as $item){
            $this->db->query(
                "DELETE          
                FROM `s_articles_esd_serials`                        
                WHERE `s_articles_esd_serials`.`id` = :serialId",
                ['serialId' => $item['serialId']]
            );
        }

        $this->db->query(
            "DELETE 
            FROM `s_articles_esd_serials_attributes`                          
            WHERE NOT `s_articles_esd_serials_attributes`.`serialID` IN (SELECT id FROM s_articles_esd_serials)"
        );         

        $this->forward($params['sTarget'], null, null, $params);
    }
    
    private function clearParams($params = []) {
        foreach($params as &$param) {
            $param = htmlspecialchars(stripslashes(trim($param)));
        }
        
        return $params;
    }

    private function getSerialsCount($esdId){          
        //get all serials count by esdId
        $allSerialCount = $this->db->fetchOne(
            'SELECT COUNT(*)
            FROM s_articles_esd_serials             
            WHERE s_articles_esd_serials.esdID = :esdID',            
            ['esdID' => $esdId]
        );
        //select all used serials count by esdId
        $usedSerialCount = $this->db->fetchOne(
            'SELECT COUNT(*)
            FROM s_articles_esd_serials
            WHERE s_articles_esd_serials.id IN (SELECT serialID FROM s_order_esd)
            AND s_articles_esd_serials.esdID= :esdID',            
            ['esdID' => $esdId]
        );
        
        $freeSerialsCount = $allSerialCount - $usedSerialCount;

        if (($freeSerialsCount) < 0){
            $allSerialCount = $usedSerialCount;
            $freeSerialsCount = 0;
        }

        return [
            'all' => $allSerialCount, 
            'used' => $usedSerialCount,
            'free' => $freeSerialsCount
        ];
    }

    private function getFreeCount($esdId){
        return $this->db->fetchOne(
            "SELECT COUNT(*)
            FROM `s_articles_esd_serials`                   
            WHERE `s_articles_esd_serials`.`esdID` = $esdId
            AND NOT `s_articles_esd_serials`.`id` IN (SELECT serialID FROM s_order_esd)"
        );
    }

    private function getUsedCount($esdId){
        return $this->db->fetchOne(
            "SELECT COUNT(*)
            FROM s_articles_esd_serials
            WHERE s_articles_esd_serials.id IN (SELECT serialID FROM s_order_esd)
            AND s_articles_esd_serials.esdID = $esdId"
        );
    }

    private function getFreeSerials($esdId,$offset){         

        $serials = $this->db->fetchAll(
            "SELECT `s_articles_esd_serials`.`id` as `serialId`,
            `s_articles_esd_serials`.`serialnumber`,
            `s_articles_esd_serials`.`esdID` as `esdId`            
            FROM `s_articles_esd_serials`                                 
            WHERE `s_articles_esd_serials`.`esdID` = $esdId
            AND NOT `s_articles_esd_serials`.`id` IN (SELECT serialID FROM s_order_esd)
            ORDER BY `s_articles_esd_serials`.`id` DESC
            LIMIT $offset, $this->limit"
        );  
        
        //speed optimzed
        foreach ($serials as &$serial){
            $attr = $this->db->fetchRow(
                "SELECT `s_articles_esd_serials_attributes`.`id` as `serialAttrId`,
                `s_articles_esd_serials_attributes`.`dealer` as `serialDealer`,
                `s_articles_esd_serials_attributes`.`import_date`
                FROM `s_articles_esd_serials_attributes`                                     
                WHERE `s_articles_esd_serials_attributes`.`serialID` = :serialId",
                ['serialId' => $serial['serialId']]
            );   
            if ($attr){
                $serial = array_merge($serial, $attr); 
            }                                   
        }
        
        return $serials;
    }    

    private function getUsedSerials($esdId,$offset){
        return $this->db->fetchAll(
            "SELECT `s_articles_esd_serials`.`id` as `serialId`,
            `s_articles_esd_serials`.`serialnumber`,
            `s_articles_esd_serials`.`esdID` as `esdId`,
            `s_articles_esd_serials_attributes`.`id` as `serialAttrId`,
            `s_articles_esd_serials_attributes`.`dealer` as `serialDealer`,
            `s_articles_esd_serials_attributes`.`import_date`,
            `s_order_esd`.`esdID` as `used`,
            `s_order_esd`.`userID` as `userId`,
            `s_order_esd`.`orderID` as `orderId`,
            `s_order_esd`.`datum` as `order_date`
            FROM `s_articles_esd_serials`   
            LEFT JOIN `s_articles_esd_serials_attributes`
            ON `s_articles_esd_serials`.`id` = `s_articles_esd_serials_attributes`.`serialID`           
            INNER JOIN `s_order_esd`
            ON `s_articles_esd_serials`.`id` = `s_order_esd`.`serialID`           
            WHERE `s_articles_esd_serials`.`esdID` = $esdId
            ORDER BY `s_order_esd`.`datum` DESC
            LIMIT $offset, $this->limit"
        );
    }

    private function getArticle($ordernumber){
        return $this->db->fetchRow(
            'SELECT `s_articles_details`.`id` as detailId,
            `s_articles_details`.`ordernumber`,
            `s_articles_details`.`articleID`,
            `s_articles_esd`.`id` as esdId,
            `s_articles_esd`.`serials`, 
            `s_articles`.`name`          
             FROM `s_articles_details`
             LEFT JOIN `s_articles_esd`
             ON `s_articles_details`.`id` = `s_articles_esd`.`articledetailsID`
             LEFT JOIN `s_articles`
             ON `s_articles_details`.`articleID` = `s_articles`.`id`
             WHERE `s_articles_details`.`ordernumber` = :ordernumber',
            ['ordernumber' => $ordernumber]
        );     
    }

    private function searchResultKey($term){        

        $return['free'] = $this->db->fetchAll(
            "SELECT `s_articles_esd_serials`.`id` as `serialId`,
            `s_articles_esd_serials`.`serialnumber`,
            `s_articles_esd_serials`.`esdID` as `esdId`,
            `s_articles_esd_serials_attributes`.`id` as `serialAttrId`,
            `s_articles_esd_serials_attributes`.`dealer` as `serialDealer`,
            `s_articles_esd_serials_attributes`.`import_date`
            FROM `s_articles_esd_serials`   
            LEFT JOIN `s_articles_esd_serials_attributes`
            ON `s_articles_esd_serials`.`id` = `s_articles_esd_serials_attributes`.`serialID`           
            LEFT JOIN `s_order_esd`
            ON `s_articles_esd_serials`.`id` = `s_order_esd`.`serialID`           
            WHERE `s_articles_esd_serials`.`serialnumber` LIKE '%$term%'
            AND NOT `s_articles_esd_serials`.`id` IN (SELECT serialID FROM s_order_esd)
            ORDER BY `s_articles_esd_serials`.`id` DESC"
        );

        $return['used'] = $this->db->fetchAll(
            "SELECT `s_articles_esd_serials`.`id` as `serialId`,
            `s_articles_esd_serials`.`serialnumber`,
            `s_articles_esd_serials`.`esdID` as `esdId`,
            `s_articles_esd_serials_attributes`.`id` as `serialAttrId`,
            `s_articles_esd_serials_attributes`.`dealer` as `serialDealer`,
            `s_articles_esd_serials_attributes`.`import_date`,
            `s_order_esd`.`esdID` as `used`,
            `s_order_esd`.`userID` as `userId`,
            `s_order_esd`.`orderID` as `orderId`,
            `s_order_esd`.`datum` as `order_date`
            FROM `s_articles_esd_serials`   
            LEFT JOIN `s_articles_esd_serials_attributes`
            ON `s_articles_esd_serials`.`id` = `s_articles_esd_serials_attributes`.`serialID`           
            INNER JOIN `s_order_esd`
            ON `s_articles_esd_serials`.`id` = `s_order_esd`.`serialID`           
            WHERE `s_articles_esd_serials`.`serialnumber` LIKE '%$term%'
            ORDER BY `s_order_esd`.`datum` DESC"
        );

        foreach ($return['used'] as &$usedSerial){
            $usedSerial['orderOrdernumber'] = $this->db->fetchOne(
                'SELECT ordernumber                   
                 FROM s_order       
                 WHERE s_order.id = :orderId',
                ['orderId' => $usedSerial['orderId']]
            ); 

            $usedSerial['userEmail'] = $this->db->fetchOne(
                'SELECT email                   
                 FROM s_user       
                 WHERE s_user.id = :userId',
                ['userId' => $usedSerial['userId']]
            ); 
        }       

        $return['term'] = $term;
        
        return $return;
    }

    private function getFreeSerialsDealer($term, $offset){
        return $this->db->fetchAll(
            "SELECT `s_articles_esd_serials_attributes`.`id` as `serialAttrId`,
            `s_articles_esd_serials_attributes`.`serialID` as `serialId`,
            `s_articles_esd_serials_attributes`.`dealer` as `serialDealer`,
            `s_articles_esd_serials_attributes`.`import_date`,
            `s_articles_esd_serials`.`serialnumber`           
            FROM `s_articles_esd_serials_attributes`     
            LEFT JOIN `s_articles_esd_serials`
            ON `s_articles_esd_serials_attributes`.`serialID` = `s_articles_esd_serials`.`id`                
            WHERE `s_articles_esd_serials_attributes`.`dealer` LIKE '%$term%'
            AND NOT `s_articles_esd_serials_attributes`.`serialID` IN (SELECT serialID FROM s_order_esd)
            ORDER BY `s_articles_esd_serials_attributes`.`id` DESC
            LIMIT $offset, $this->limit"
        );
    }      

    private function getUsedSerialsDealer($term, $offset){
        $return = $this->db->fetchAll(
            "SELECT `s_articles_esd_serials_attributes`.`id` as `serialAttrId`,
            `s_articles_esd_serials_attributes`.`serialID` as `serialId`,
            `s_articles_esd_serials_attributes`.`dealer` as `serialDealer`,
            `s_articles_esd_serials_attributes`.`import_date`,
            `s_articles_esd_serials`.`serialnumber`,
            `s_order_esd`.`userID` as `userId`,
            `s_order_esd`.`orderID` as `orderId`,
            `s_order_esd`.`datum` as `order_date`          
            FROM `s_articles_esd_serials_attributes`     
            LEFT JOIN `s_articles_esd_serials`
            ON `s_articles_esd_serials_attributes`.`serialID` = `s_articles_esd_serials`.`id`  
            INNER JOIN `s_order_esd`
            ON `s_articles_esd_serials_attributes`.`serialID` = `s_order_esd`.`serialID`              
            WHERE `s_articles_esd_serials_attributes`.`dealer` LIKE '%$term%'
            AND `s_articles_esd_serials_attributes`.`serialID` IN (SELECT serialID FROM s_order_esd)
            ORDER BY `s_articles_esd_serials_attributes`.`id` DESC
            LIMIT $offset, $this->limit"
        );

        foreach ($return as &$usedSerial){
            $usedSerial['orderOrdernumber'] = $this->db->fetchOne(
                'SELECT ordernumber                   
                 FROM s_order       
                 WHERE s_order.id = :orderId',
                ['orderId' => $usedSerial['orderId']]
            ); 

            $usedSerial['userEmail'] = $this->db->fetchOne(
                'SELECT email                   
                 FROM s_user       
                 WHERE s_user.id = :userId',
                ['userId' => $usedSerial['userId']]
            ); 
        }
               
        return $return;
    }
    
    private function searchResultDealerCount($term){  
             
        $return['free'] = $this->db->fetchOne(
            "SELECT COUNT(*)        
            FROM `s_articles_esd_serials_attributes`     
            LEFT JOIN `s_articles_esd_serials`
            ON `s_articles_esd_serials_attributes`.`serialID` = `s_articles_esd_serials`.`id`                
            WHERE `s_articles_esd_serials_attributes`.`dealer` LIKE '%$term%'
            AND NOT `s_articles_esd_serials_attributes`.`serialID` IN (SELECT serialID FROM s_order_esd)"
        );

        $return['used'] = $this->db->fetchOne(
            "SELECT COUNT(*)          
            FROM `s_articles_esd_serials_attributes`     
            LEFT JOIN `s_articles_esd_serials`
            ON `s_articles_esd_serials_attributes`.`serialID` = `s_articles_esd_serials`.`id`  
            INNER JOIN `s_order_esd`
            ON `s_articles_esd_serials_attributes`.`serialID` = `s_order_esd`.`serialID`              
            WHERE `s_articles_esd_serials_attributes`.`dealer` LIKE '%$term%'
            AND `s_articles_esd_serials_attributes`.`serialID` IN (SELECT serialID FROM s_order_esd)"
        );

        $return['all'] = $return['free'] + $return['used'];
        
        $return['term'] = $term;
        
        return $return;
    }

    private function getPagination($count, $page){       
        $pagination['pages'] = ceil($count / $this->limit);
        $pagination['page'] = $page;
        if ($pagination['page'] < 1){
            $pagination['page'] = 1;
        }        
        
        if ($pagination['page'] > $pagination['pages']){
            $pagination['page'] = $pagination['pages'];
        }
        $pagination['offset'] = ($pagination['page'] - 1)  * $this->limit; 
        
        if (($pagination['page'] - 1) > 0){
            $pagination['previous'] = $pagination['page'] - 1;              
        }

        if (($pagination['page'] + 1) < $pagination['pages']){
            $pagination['next'] = $pagination['page'] + 1;                
        }        

        return $pagination;
    }
}