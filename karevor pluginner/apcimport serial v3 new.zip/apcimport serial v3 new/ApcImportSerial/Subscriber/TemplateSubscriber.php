<?php

namespace ApcImportSerial\Subscriber;

use Enlight\Event\SubscriberInterface;

class TemplateSubscriber implements SubscriberInterface
{
    /**
     * @var
     */
    private $pluginDirectory;  
    /**
     * @param $pluginDirectory
     */
    public function __construct($pluginDirectory)
    {
        $this->pluginDirectory = $pluginDirectory;
    }
    /**
     * @return array
     */
    public static function getSubscribedEvents()
    {
        return [
            'Theme_Inheritance_Template_Directories_Collected' => 'onCollectTemplateDirs',   
            'sOrder::sSaveOrder::after' => 'afterOrder',
        ];
    }    
     /**
     * @param Enlight_Event_EventArgs $args
     */
    public function onCollectTemplateDirs(\Enlight_Event_EventArgs $args) {
        $dirs = $args->getReturn();
        $dirs[] = $this->pluginDirectory . '/Resources/views';
        return $dirs;
    }
    
     /**
     * @param \Enlight_Hook_HookArgs $args
     */
    public function afterOrder(\Enlight_Hook_HookArgs $args)
    {
        $pluginDir = $this->pluginDirectory;
        $orderNumber = $args->getReturn();
        $art_onums = Shopware()->Db()->fetchAll(
            'SELECT articleordernumber, name
            FROM s_order_details            
            WHERE s_order_details.ordernumber = :ordernumber',            
            ['ordernumber' => $orderNumber]
        );
        
        $i = -1;
        foreach($art_onums as &$art_onum){
            $i++;
            $art_onum['art_details_id'] = Shopware()->Db()->fetchOne(
                'SELECT id
                FROM s_articles_details             
                WHERE s_articles_details.ordernumber = :ordernumber',            
                ['ordernumber' => $art_onum['articleordernumber']]
            );
            $art_onum['esd_id'] = Shopware()->Db()->fetchOne(
                'SELECT id
                FROM s_articles_esd             
                WHERE s_articles_esd.articledetailsID = :articledetailsID',            
                ['articledetailsID' => $art_onum['art_details_id']]
            );
            $esdAttr = Shopware()->Db()->fetchRow(
                'SELECT esd_serial_limit_active, esd_serial_limit
                FROM s_articles_esd_attributes             
                WHERE s_articles_esd_attributes.esdID = :esdID',            
                ['esdID' => $art_onum['esd_id']]
            );
            $art_onum['esd_active'] = $esdAttr['esd_serial_limit_active'];
            $art_onum['esd_limit'] = $esdAttr['esd_serial_limit'];
            if($art_onum['esd_active'] != 1 || $art_onum['esd_limit'] < 1){
                unset($art_onums["$i"]);
            }
        }
        
        if (!$art_onums){
            return;
        }
        $i = -1;
        foreach ($art_onums as &$art_onum){
            $i++;
            //get all serials count by esdId 
            $art_onum['allcount'] = Shopware()->Db()->fetchOne(
                'SELECT COUNT(*)
                FROM s_articles_esd_serials             
                WHERE s_articles_esd_serials.esdID = :esdID',            
                ['esdID' => $art_onum['esd_id']]
            );
            //select all used serials count by esdId
            $art_onum['used_count'] = Shopware()->Db()->fetchOne(
                'SELECT COUNT(*)
                FROM s_articles_esd_serials
                WHERE s_articles_esd_serials.id IN (SELECT serialID FROM s_order_esd)
                AND s_articles_esd_serials.esdID= :esdID',            
                ['esdID' => $art_onum['esd_id']]
            );
            $art_onum['free_count'] = $art_onum['allcount'] - $art_onum['used_count'];
            if ($art_onum['free_count'] < $art_onum['esd_limit']){
                $art_onum['sms'] = $art_onum['name'] . ' (' . $art_onum['articleordernumber'] . ') is ' . $art_onum['free_count'];
            }else{
                unset($art_onums["$i"]);
            }
        }
        if (!$art_onums){
            return;
        }
        
        $message = Shopware()->Container()->get('apc_import_serial.message_bird_api_service');
        $message->sendMessage($art_onums, $pluginDir);
        return;
    }
}













